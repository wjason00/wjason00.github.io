# Fixed-schedule timing pilot

Frozen plan: PLAN.md. New isolated source; historical runners remain unchanged.

Schedules use five private PCG64 seeds 1001–1005, each selecting 50 unique ticks from 5000. Each GRN receives the same irregular template (aligned) or an independently uniform circular shift (staggered, first GRN anchored at zero), repeated three times. The middle half-open 500 ms is analysed. Scheduled counts and amplitudes match; refractory-applied events and actual GRN spikes are recorded separately. No acceptance override or steady-state claim.

Reuse: paired_runner_v4.build and original CandidateDrive/ReferenceDrive. Added selective GRN/Roundup spike monitor is installed before replacing the initial network store. All Python drive records are armed after every restore. Baseline weights are restored, then every exact direct-edge row or all outgoing rows is set to zero. Noncut weights are checked exactly; incoming cuts can only be genuine self-loops and are disclosed.

Run from this directory with ../.venv/Scripts/python.exe:

1. `test_timing.py` (small fixture only).
2. `timing_runner.py freeze` (refuses overwrite; freezes source/package/protocol/schedule hashes).
3. `timing_runner.py gate --out gate-attempt01 --deadline-utc <UTC>` (candidate/reference full-model equality and both timing intact benchmarks).
4. After root reviews gate/runtime: `timing_runner.py grid --out grid-attempt01 --reuse-gate gate-attempt01 --deadline-utc <UTC>`.

Every completed cell saves raw arrays and metadata before validation and aggregation. Interrupted attempts retain completed files and failure/watchdog evidence. Grid retains the two identical frozen scientific gate intacts with explicit provenance; other 28 cells execute serially. `cells.csv`, `pairs.json`, `interactions.json` use count losses N_intact−N_cut and staggered−aligned excess-all loss. Latency fields mean first spike after the middle-window start (0.5 s), relative to that window start during ongoing periodic drive; they are not stimulus-onset or behavioural latencies. No spike in the window means missing latency, never zero. No p-values, biological validation, causal inhibition, mediation fraction or field-novelty claim.

Original native watchdog minimums and one numerical lock are retained. Protocol admission is 4 GiB RAM / 5 GiB commit / 1.5 GiB disk; watchdog stops process below 2 / 3 / 1 GiB or at deadline. Platform/package/source manifest is saved for every attempt.
