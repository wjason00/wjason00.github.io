"""Small independent invariants and integration fixtures; no full-network execution."""
import json
from pathlib import Path
import time
import numpy as np
from timing_inputs import schedule,window,intervention_masks,digest,SEEDS
import timing_runner as run


def main():
    start=time.monotonic(); templates=[]
    for seed in SEEDS:
        aligned,m=schedule(seed,'aligned'); staggered,n=schedule(seed,'staggered')
        templates.append(tuple(m['template_ticks']))
        assert aligned.shape==staggered.shape==(15000,21)
        assert np.all(aligned[:5000].sum(axis=0)==50)
        assert np.all(staggered[:5000].sum(axis=0)==50)
        assert np.array_equal(aligned[:,0],staggered[:,0])
        assert np.all(aligned==aligned[:,0,None])
        intervals=np.diff(np.r_[m['template_ticks'],m['template_ticks'][0]+5000])
        assert len(np.unique(intervals))>1 and intervals.sum()==5000
        for column,shift in enumerate(n['circular_shifts_ticks']):
            assert np.array_equal(staggered[:5000,column],np.roll(aligned[:5000,column],shift))
        assert np.array_equal(staggered,schedule(seed,'staggered')[0])
    assert len(set(templates))==5
    assert window([0,.4999,.5,.9999,1.,1.5]).tolist()==[False,False,True,True,False,False]
    masks=intervention_masks([1,1,1,0,2],[3,3,1,1,1],1,3)
    assert np.flatnonzero(masks['direct']).tolist()==[0,1]
    assert np.flatnonzero(masks['all_outgoing']).tolist()==[0,1,2]
    weights=np.array([1.,2.,3.,4.,5.]); cut=weights.copy(); cut[masks['all_outgoing']]=0
    assert np.array_equal(cut,[0,0,0,4,5])  # incoming preserved except genuine self-loop
    b=run.build(tiny=True)
    # Deliberately nonzero refractory in this fixture only: ensure rejection is exercised.
    # The full scientific build retains the original GRN rfc=0 setting.
    from brian2 import ms
    b['neu'][b['exc'][0]].rfc=25*ms
    b['net'].store('initial')
    r,a=run.trial(b,1001,'aligned','intact'); run.validate(b,r,a)
    assert np.any(a['candidates'] * ~a['eligible'])
    s,c=run.trial(b,1001,'aligned','intact','reference'); run.validate(b,s,c)
    assert r['initial_state']==s['initial_state']
    keys=['counts','mn9_times_seconds','selected_indices','selected_times_seconds','before_v','after_v','eligible','candidates','applied']+['final_'+key for key in run.old.STATE]
    for key in keys: assert np.array_equal(a[key],c[key]),key
    t,d=run.trial(b,1001,'aligned','intact'); run.validate(b,t,d)
    for key in a: assert np.array_equal(a[key],d[key]),key
    for condition in ('direct','all_outgoing'):
        r,a=run.trial(b,1001,'staggered',condition); run.validate(b,r,a)
    receipt=dict(passed=True,small_network_only=True,fixture_seconds=time.monotonic()-start,
        checks=['50 unique events/period/GRN','5 distinct irregular templates','circular shift/wrap/repeat',
        'half-open middle window','all multiedge rows/selfloop/incoming','candidate-reference exact voltage/state/spikes',
        'restore selected monitor and drive records','replay exact','both interventions',
        'refractory-blocked candidate rejection actually exercised'],
        source_hashes={name:run.old.sha(Path(__file__).parent/name) for name in ('timing_inputs.py','timing_runner.py','test_timing.py')})
    (Path(__file__).parent/'fixture.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt,indent=2))


if __name__=='__main__': main()
