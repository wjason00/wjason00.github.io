"""Frozen periodic external-event schedules; applied events remain endogenous."""
import hashlib
import numpy as np

DT = .0001
PERIOD_TICKS = 5000
EVENTS = 50
REPEATS = 3
SEEDS = tuple(range(1001, 1006))


def digest(a):
    a = np.ascontiguousarray(a)
    return hashlib.sha256(str(a.dtype).encode() + str(a.shape).encode() + a.tobytes()).hexdigest()


def schedule(seed, pattern, inputs=21):
    if seed not in SEEDS or pattern not in ('aligned', 'staggered') or inputs < 1:
        raise ValueError('Invalid schedule specification')
    rng = np.random.Generator(np.random.PCG64(seed))
    template = np.sort(rng.choice(PERIOD_TICKS, EVENTS, replace=False))
    shifts = np.zeros(inputs, dtype=np.int64)
    if pattern == 'staggered':
        shifts[1:] = rng.integers(0, PERIOD_TICKS, size=inputs-1)
    period = np.zeros((PERIOD_TICKS, inputs), dtype=np.uint8)
    for column, shift in enumerate(shifts):
        period[(template + shift) % PERIOD_TICKS, column] = 1
    data = np.tile(period, (REPEATS, 1))
    assert np.all(period.sum(axis=0) == EVENTS)
    assert np.array_equal(data[:PERIOD_TICKS], data[PERIOD_TICKS:2*PERIOD_TICKS])
    data.flags.writeable = False
    return data, dict(seed=seed, pattern=pattern, template_ticks=template.tolist(),
                     circular_shifts_ticks=shifts.tolist(), sha256=digest(data))


def window(times):
    times = np.asarray(times)
    return (times >= .5) & (times < 1.)


def intervention_masks(pre, post, lesion, endpoint):
    pre, post = np.asarray(pre), np.asarray(post)
    return dict(intact=np.zeros(len(pre), dtype=bool),
                direct=(pre == lesion) & (post == endpoint),
                all_outgoing=pre == lesion)
