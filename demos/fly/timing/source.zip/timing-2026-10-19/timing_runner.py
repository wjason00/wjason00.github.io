"""Bounded fixed-schedule timing pilot. Freeze and fixtures precede full execution."""
import argparse
import datetime as dt
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys
import time
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'paired-2026-10-13'))
import paired_runner_v4 as old
from timing_inputs import schedule, window, intervention_masks, digest, SEEDS
import numpy as np


def build(tiny=False):
    from brian2 import SpikeMonitor
    b = old.build(tiny=tiny)
    selected = list(b['exc']) + [b['lesion']]
    assert len(set(selected)) == len(selected)
    b['selected_indices'] = selected
    b['selected'] = [SpikeMonitor(b['neu'][i:i+1], record=True,
                     name=f'timing_selected_spikes_{column}') for column,i in enumerate(selected)]
    b['net'].add(*b['selected'])
    b['net'].store('initial')  # includes the added monitor, replacing initial snapshot
    pre = np.asarray(b['syn'].i[:])
    post = np.asarray(b['syn'].j[:])
    b['masks'] = intervention_masks(pre, post, b['lesion'], b['endpoint'])
    b['incoming'] = post == b['lesion']
    b['selfloop'] = (pre == b['lesion']) & (post == b['lesion'])
    assert np.array_equal(np.flatnonzero(b['masks']['all_outgoing']), b['lesion_edges'])
    b['identity'] = dict(neurons=len(b['ids']), stored_rows=len(pre),
        ordered_input_ids=[int(b['ids'][i]) for i in b['exc']],
        roundup_id=int(b['ids'][b['lesion']]), mn9_id=int(b['ids'][b['endpoint']]),
        direct_rows=int(b['masks']['direct'].sum()), outgoing_rows=int(b['masks']['all_outgoing'].sum()),
        incoming_rows=int(b['incoming'].sum()), selfloop_rows=int(b['selfloop'].sum()),
        direct_mask_sha256=digest(b['masks']['direct']), all_outgoing_mask_sha256=digest(b['masks']['all_outgoing']),
        baseline_weight_sha256=digest(b['baseline_w']))
    return b


def trial(b, seed, pattern, condition, mode='candidate'):
    from brian2 import second
    assert condition in b['masks'] and mode in ('candidate', 'reference')
    b['net'].restore('initial', restore_random_state=True)
    state = old.initial_state(b)
    assert all(len(mon.t)==0 and not np.asarray(mon.count).any() for mon in b['selected'])
    state['selected_spike_count'] = 0
    for item in b['pois']:
        item.active = False
    b['operation'].active = mode == 'candidate'
    for item in b['reference'].runners:
        item.active = mode == 'reference'
    mask = b['masks'][condition]
    for lo in range(0, len(b['syn']), 65536):
        hi = min(lo+65536, len(b['syn']))
        assert np.array_equal(b['syn'].w_[lo:hi], b['baseline_w'][lo:hi])
        expected = b['baseline_w'][lo:hi].copy()
        expected[mask[lo:hi]] = 0
        b['syn'].w_[lo:hi] = expected
        assert np.array_equal(b['syn'].w_[lo:hi], expected)
        assert np.array_equal(np.asarray(b['syn'].w_[lo:hi])[~mask[lo:hi]], b['baseline_w'][lo:hi][~mask[lo:hi]])
    data, meta = schedule(seed, pattern, inputs=len(b['exc']))
    if mode == 'candidate':
        b['drive'].arm(data)
    else:
        b['reference'].arm(data, duration_seconds=1.5)
    start = time.monotonic()
    b['net'].run(1.5 * second)
    elapsed = time.monotonic()-start
    a = dict(counts=np.asarray(b['counts'].count).copy(),
        mn9_times_seconds=np.asarray(b['endpoint_mon'].t / second).copy(),
        selected_indices=np.concatenate([np.full(len(mon.t),i,dtype=np.int32)
            for i,mon in zip(b['selected_indices'],b['selected'])]),
        selected_times_seconds=np.concatenate([np.asarray(mon.t / second)
            for mon in b['selected']]),
        before_v=np.asarray(b['before'].v).T.copy(), after_v=np.asarray(b['after'].v).T.copy(),
        eligible=np.asarray(b['before'].not_refractory).T.copy(), candidates=data.copy())
    a.update({'final_'+key: b['neu'].variables[key].get_value().copy() for key in old.STATE})
    a['applied'] = b['drive'].applied.copy() if mode == 'candidate' else data*a['eligible']
    if mode == 'candidate':
        a['seen'] = b['drive'].seen.copy()
        a['drive_eligible'] = b['drive'].eligible.copy()
    grns = []
    for i in b['exc']:
        times = a['selected_times_seconds'][a['selected_indices'] == i]
        middle=times[window(times)]
        grns.append(dict(neuron_index=int(i), full_spikes=len(times), middle_spikes=len(middle),
            middle_first_spike_latency_seconds=float(middle[0]-.5) if len(middle) else None))
    roundup = a['selected_times_seconds'][a['selected_indices'] == b['lesion']]
    mn9_middle=a['mn9_times_seconds'][window(a['mn9_times_seconds'])]
    roundup_middle=roundup[window(roundup)]
    r = dict(seed=seed, pattern=pattern, condition=condition, mode=mode, recurrent_gain=1.,
        duration_seconds=1.5, dt_seconds=.0001, analysis_window_seconds=[.5, 1.],
        analysis_window_convention='left inclusive, right exclusive',
        initial_state=state, schedule=meta, simulation_seconds=elapsed,
        final_time_seconds=float(b['net'].t / second), mn9_count=int(a['counts'][b['endpoint']]),
        total_spikes=int(a['counts'].sum()), mn9_middle_count=int(window(a['mn9_times_seconds']).sum()),
        roundup_middle_count=int(window(roundup).sum()), grn_spikes=grns,
        mn9_middle_first_spike_latency_seconds=float(mn9_middle[0]-.5) if len(mn9_middle) else None,
        roundup_middle_first_spike_latency_seconds=float(roundup_middle[0]-.5) if len(roundup_middle) else None,
        scheduled_per_grn_full=a['candidates'].sum(axis=0).tolist(),
        applied_per_grn_full=a['applied'].sum(axis=0).tolist(),
        scheduled_per_grn_middle=a['candidates'][5000:10000].sum(axis=0).tolist(),
        applied_per_grn_middle=a['applied'][5000:10000].sum(axis=0).tolist(),
        zeroed_mask_rows=int(mask.sum()), noncut_weights_exact=True,
        incoming_rows_cut=int((b['incoming'] & mask).sum()), selfloop_rows=int(b['selfloop'].sum()),
        arrays_sha256={k:digest(v) for k,v in a.items()})
    return r, a


def validate(b, r, a):
    old.validate(b, r, a)
    assert len(a['selected_times_seconds']) == len(a['selected_indices'])
    assert set(np.unique(a['selected_indices'])).issubset(set(b['exc']) | {b['lesion']})
    for i in list(b['exc']) + [b['lesion']]:
        assert (a['selected_indices'] == i).sum() == a['counts'][i]
    assert np.all(a['candidates'].sum(axis=0) == 150)
    assert np.all(a['candidates'][5000:10000].sum(axis=0) == 50)
    assert r['incoming_rows_cut'] == (r['selfloop_rows'] if r['condition']=='all_outgoing' else 0)


def source_paths():
    prior = json.loads((ROOT/'paired-2026-10-13/PROTOCOL-v4.json').read_text())
    paths = list(prior['sha256'])
    paths += ['paired-2026-10-13/PROTOCOL-v4.json']
    paths += [str(p.relative_to(ROOT)).replace('\\','/') for p in (HERE/'timing_inputs.py', HERE/'timing_runner.py', HERE/'test_timing.py')]
    return sorted(set(paths))


def freeze():
    target = HERE/'PROTOCOL.json'
    if target.exists():
        raise RuntimeError('Protocol already frozen')
    fixture = json.loads((HERE/'fixture.json').read_text())
    assert fixture['passed']
    assert fixture['source_hashes']=={name:old.sha(HERE/name) for name in
        ('timing_inputs.py','timing_runner.py','test_timing.py')}, 'Fixture sources changed; rerun fixture'
    oldp = json.loads((ROOT/'paired-2026-10-13/PROTOCOL-v4.json').read_text())
    for rel, expected in oldp['sha256'].items():
        assert old.sha(ROOT/rel) == expected, rel
    schedules = {}
    for seed in SEEDS:
        for pattern in ('aligned','staggered'):
            data, meta = schedule(seed, pattern)
            np.save(HERE/f'schedule-{seed}-{pattern}.npy', data)
            schedules[f'{seed}-{pattern}'] = meta
    p = dict(frozen_utc=dt.datetime.now(dt.timezone.utc).isoformat(), before_full_network_execution=True,
        upstream_commit=oldp['upstream_commit'], python=platform.python_version(), packages=oldp['packages'],
        sha256={rel:old.sha(ROOT/rel) for rel in source_paths()},
        fixture_sha256=old.sha(HERE/'fixture.json'), schedules=schedules,
        conditions=['intact','direct','all_outgoing'], seeds=list(SEEDS), gain=1.,
        dt_seconds=.0001, period_seconds=.5, repeats=3, scheduled_events_per_grn_period=50,
        external_amplitude_volts=.06875, analysis_window_seconds=[.5,1.], window='half-open',
        acceptance='original not_refractory; no forcing/clamp',
        admission_minimum_GiB=oldp['admission_minimum_GiB'], resource_minimum_GiB=oldp['resource_minimum_GiB'],
        maximum_attempt_seconds=4500, task_started_utc='2026-10-19T21:21:00Z',
        task_maximum_seconds=4500, numerical_hard_ceiling_utc='2026-10-19T22:25:00Z',
        planned_scientific_cells=30,
        estimand='L=N_intact-N_cut; interaction=(L_all-L_direct)_staggered-(L_all-L_direct)_aligned',
        limitations=['No steady-state claim','Scheduled events matched; applied events and GRN spikes audited separately',
        'No biological validation, causal inhibition, mediated fraction, or novelty claim'])
    target.write_text(json.dumps(p, indent=2))
    print(json.dumps(dict(frozen=True, protocol_sha256=old.sha(target))), flush=True)


def main():
    if not __debug__:
        raise SystemExit('Assertions required')
    ap=argparse.ArgumentParser()
    ap.add_argument('action',choices=['freeze','gate','grid'])
    ap.add_argument('--out',type=Path)
    ap.add_argument('--deadline-utc')
    ap.add_argument('--reuse-gate',type=Path)
    args=ap.parse_args()
    if args.action=='freeze':
        freeze(); return
    protocol=HERE/'PROTOCOL.json'; p=json.loads(protocol.read_text()); protocol_sha=old.sha(protocol)
    deadline_value=dt.datetime.fromisoformat(args.deadline_utc.replace('Z','+00:00'))
    assert deadline_value.utcoffset()==dt.timedelta(0)
    deadline=deadline_value.timestamp()
    assert time.time()<deadline<=time.time()+p['maximum_attempt_seconds']
    task_started=dt.datetime.fromisoformat(p['task_started_utc'].replace('Z','+00:00')).timestamp()
    hard_ceiling=dt.datetime.fromisoformat(p['numerical_hard_ceiling_utc'].replace('Z','+00:00')).timestamp()
    assert deadline<=min(hard_ceiling,task_started+p['task_maximum_seconds']), 'Deadline exceeds frozen task ceiling'
    out=args.out.resolve(); assert out.is_relative_to(HERE)
    out.mkdir(exist_ok=False)
    wd=old.Watchdog(str(out),deadline)
    reason=wd.sample()
    for key,minimum in p['admission_minimum_GiB'].items():
        if wd.mins[key]<minimum*2**30:
            reason=reason or f'Admission {key}: below {minimum} GiB'
    (out/'attempt.json').write_text(json.dumps(dict(action=args.action, pid=os.getpid(), admitted=reason is None,
        started_utc=dt.datetime.now(dt.timezone.utc).isoformat(), deadline_utc=args.deadline_utc,
        protocol_sha256=protocol_sha, resources=wd.mins),indent=2))
    if reason:
        wd.stop_reason=reason; wd.write('refused_preflight'); raise RuntimeError(reason)
    lock=ROOT/'feasibility-2026-10-13/numerical.lock'; acquired=False
    try:
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY); acquired=True
        with os.fdopen(fd,'w') as f: f.write(str(os.getpid()))
        wd.start()
        assert platform.python_version()==p['python']
        for package,version in p['packages'].items():
            assert importlib.metadata.version(package)==version,package
        for rel,expected in p['sha256'].items(): assert old.sha(ROOT/rel)==expected,rel
        assert old.sha(HERE/'fixture.json')==p['fixture_sha256']
        for label,meta in p['schedules'].items():
            assert digest(np.load(HERE/f'schedule-{label}.npy'))==meta['sha256']
        (out/'runtime.json').write_text(json.dumps(dict(python=sys.version, executable=sys.executable,
            platform=platform.platform(), packages={x:importlib.metadata.version(x) for x in p['packages']},
            source_hashes=p['sha256'], codegen_target='numpy'),indent=2))
        print('Building full network',flush=True); start=time.monotonic(); b=build()
        assert b['amplitude']==p['external_amplitude_volts']
        b['identity']['build_seconds']=time.monotonic()-start
        assert b['identity']['neurons']==127400 and b['identity']['stored_rows']==14687178
        assert b['identity']['roundup_id']==720575940623211725 and b['identity']['mn9_id']==720575940660219265
        (out/'identity.json').write_text(json.dumps(b['identity'],indent=2))
        np.savez_compressed(out/'network_identity.npz', ids=b['ids'],exc=b['exc'],
            direct_rows=np.flatnonzero(b['masks']['direct']),outgoing_rows=np.flatnonzero(b['masks']['all_outgoing']),
            incoming_rows=np.flatnonzero(b['incoming']),selfloop_rows=np.flatnonzero(b['selfloop']))
        def save(label,r,a):
            r.update(protocol_sha256=protocol_sha, saved_utc=dt.datetime.now(dt.timezone.utc).isoformat())
            np.savez_compressed(out/(label+'.npz'),**a)
            (out/(label+'.json')).write_text(json.dumps(r,indent=2))
            assert r['schedule']==p['schedules'][f"{r['seed']}-{r['pattern']}"]
            validate(b,r,a)
            print(json.dumps(dict(label=label,mn9_middle_count=r['mn9_middle_count'],simulation_seconds=r['simulation_seconds'])),flush=True)
            wd.write(label)
        if args.action=='gate':
            base,a=trial(b,1001,'aligned','intact'); save('seed-1001_aligned_intact',base,a)
            other,c=trial(b,1001,'aligned','intact','reference'); save('gate-reference',other,c)
            assert base['initial_state']==other['initial_state']
            keys=['counts','mn9_times_seconds','selected_indices','selected_times_seconds','before_v','after_v','eligible','candidates','applied']+['final_'+key for key in old.STATE]
            for key in keys: assert np.array_equal(a[key],c[key]),key
            generated=b['reference'].generated_code()
            assert len(generated)==len(b['exc']) and all('not_refractory' in code for code in generated.values())
            (out/'reference-generated-code.json').write_text(json.dumps(generated,indent=2))
            # The second timing pattern is the other intact benchmark; no cut output inspected.
            r,z=trial(b,1001,'staggered','intact'); save('seed-1001_staggered_intact',r,z)
            assert r['initial_state']==base['initial_state']
            success_name='gate.json'
            success_record=dict(passed=True,protocol_sha256=protocol_sha,
                candidate_reference_exact_keys=keys, selected_monitor_restore=True,
                benchmark_intacts=['seed-1001_aligned_intact','seed-1001_staggered_intact'],
                retained_scientific_intacts=True, estimated_grid_simulation_seconds=15*(base['simulation_seconds']+r['simulation_seconds']))
        else:
            assert args.reuse_gate is not None, 'Grid requires prior reviewed gate'
            assert args.reuse_gate.resolve().is_relative_to(HERE)
            assert not (args.reuse_gate/'failure.json').exists(), 'Gate has failure evidence'
            gate=json.loads((args.reuse_gate/'gate.json').read_text())
            assert gate['passed'] and gate['protocol_sha256']==protocol_sha
            rows=[]; pairs=[]
            for seed in SEEDS:
                for pattern in ('aligned','staggered'):
                    cells={}
                    for condition in p['conditions']:
                        label=f'seed-{seed}_{pattern}_{condition}'
                        if seed==1001 and condition=='intact':
                            r=json.loads((args.reuse_gate/(label+'.json')).read_text())
                            assert r['protocol_sha256']==protocol_sha
                            r=dict(r,retained_from=str(args.reuse_gate.resolve()))
                            (out/(label+'.json')).write_text(json.dumps(r,indent=2))
                        else:
                            r,a=trial(b,seed,pattern,condition); save(label,r,a)
                        cells[condition]=r['mn9_middle_count']; rows.append(r)
                    pairs.append(dict(seed=seed,pattern=pattern,**cells,
                        loss_direct=cells['intact']-cells['direct'],loss_all=cells['intact']-cells['all_outgoing'],
                        excess_all_loss=cells['direct']-cells['all_outgoing']))
                    (out/'pairs.json').write_text(json.dumps(pairs,indent=2))
            interactions=[]
            for seed in SEEDS:
                aligned=next(x for x in pairs if x['seed']==seed and x['pattern']=='aligned')
                staggered=next(x for x in pairs if x['seed']==seed and x['pattern']=='staggered')
                interactions.append(dict(seed=seed,interaction=staggered['excess_all_loss']-aligned['excess_all_loss']))
            import csv
            with (out/'cells.csv').open('w',newline='') as f:
                fields=['seed','pattern','condition','mn9_middle_count','roundup_middle_count','simulation_seconds','protocol_sha256']
                writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); writer.writeheader(); writer.writerows(rows)
            (out/'interactions.json').write_text(json.dumps(interactions,indent=2))
            success_name='completion.json'
            success_record=dict(complete=True,scientific_cells=len(rows),
                simulated_here=28,retained_gate_intacts=2,biological_validation=False)
        for rel,expected in p['sha256'].items(): assert old.sha(ROOT/rel)==expected,rel
        assert old.sha(protocol)==protocol_sha, 'Frozen protocol changed during execution'
        (out/success_name).write_text(json.dumps(success_record,indent=2))
        wd.write('completed')
    except Exception as exc:
        (out/'failure.json').write_text(json.dumps(dict(type=type(exc).__name__,message=str(exc),complete=False,
            utc=dt.datetime.now(dt.timezone.utc).isoformat()),indent=2)); raise
    finally:
        if acquired and lock.exists() and lock.read_text()==str(os.getpid()): lock.unlink()


if __name__=='__main__': main()
