# Source attribution and scope

Upstream model: Philip Shiu and Nico Spiller (2023), Drosophila_brain_model,
commit 91bdd1e7dcf193f3e7ca5a8933497fcef63b7960. The unmodified upstream
MIT notice is included at upstream/shiu_91bdd1e/LICENSE. Cite Shiu et al.,
Nature 634, 210-219 (2024), https://doi.org/10.1038/s41586-024-07763-9.

The upstream source is distinct from the local timing experiment, loader,
resource guards, fixtures, protocols and input schedules archived here.
No new blanket licence for those additions is asserted by this package.

Required connectome data are not bundled. FlyWire-derived data retain their
CC BY-NC 4.0 terms, https://creativecommons.org/licenses/by-nc/4.0/ ; source
terms https://edit.flywire.ai/principles.html . Credit the FlyWire Consortium;
Dorkenwald et al. (2024), https://doi.org/10.1038/s41586-024-07558-y ;
Schlegel et al. (2024), https://doi.org/10.1038/s41586-024-07686-5 ;
Buhmann et al. (2021), https://doi.org/10.1038/s41592-021-01183-7 ;
Heinrich et al. (2018), https://doi.org/10.1007/978-3-030-00934-2_36 ;
Eckstein, Bates et al. (2024), https://doi.org/10.1016/j.cell.2024.03.016.
Names, FlyWire IDs and signed connectivity used by the protocol derive from
those sources. Timing inputs and interventions are artificial model tests.
