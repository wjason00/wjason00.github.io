"""Frozen paired recurrent-gain experiment. One process, observed common input."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import time

for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
IMPL = ROOT / 'feasibility-2026-10-13/implementation'
UP = ROOT / 'upstream/shiu_91bdd1e'
sys.path.insert(0, str(IMPL))
sys.path.insert(0, str(UP))
from runner import Watchdog, sha


def digest_array(a):
    import numpy as np
    a = np.ascontiguousarray(a)
    return hashlib.sha256(str(a.dtype).encode() + str(a.shape).encode() + a.tobytes()).hexdigest()


def build(tiny=False):
    import numpy as np
    import pandas as pd
    from brian2 import (NeuronGroup, Synapses, PoissonInput, SpikeMonitor,
                        StateMonitor, Network, seed, defaultclock, prefs, ms, Hz)
    import model as up
    from loader import load_edges
    prefs.codegen.target = 'numpy'
    seed(0)
    defaultclock.dt = .1 * ms
    p = dict(up.default_params)
    p['r_poi'] = 100 * Hz
    if tiny:
        ids = np.arange(4, dtype=np.int64)
        pre = np.array([0, 1, 1, 2, 3], dtype=np.int32)
        post = np.array([1, 2, 3, 3, 2], dtype=np.int32)
        weights = np.array([400, 250, 150, 100, -20], dtype=np.int32)
        exc, endpoint, lesion = [0], 3, 1
    else:
        proto = json.loads((ROOT / 'PROTOCOL.json').read_text())
        comp = pd.read_csv(UP / '2023_03_23_completeness_630_final.csv', index_col=0)
        ids = comp.index.to_numpy(dtype=np.int64)
        assert len(ids) == len(np.unique(ids)) == 127400
        lookup = {int(x): i for i, x in enumerate(ids)}
        exc = [lookup[int(x)] for x in proto['inputs']['stimulated_neurons']]
        assert len(exc) == len(set(exc)) == 21
        endpoint = lookup[720575940660219265]
        lesion = lookup[720575940623211725]
        pre, post, weights = load_edges(UP / '2023_03_23_connectivity_630_final.parquet', len(ids), batch_size=131072)
        assert len(pre) == len(post) == len(weights) == 14687178
    neu = NeuronGroup(len(ids), p['eqs'], method='linear', threshold=p['eq_th'], reset=p['eq_rst'],
                      refractory='rfc', name='default_neurons', namespace=p)
    neu.v = p['v_0']
    neu.g = 0
    neu.rfc = p['t_rfc']
    syn = Synapses(neu, neu, 'w : volt', on_pre='g += w', delay=p['t_dly'], name='default_synapses')
    syn.connect(i=pre, j=post)
    syn.w = weights * p['w_syn']
    for lo in range(0, len(pre), 65536):
        hi = min(lo + 65536, len(pre))
        assert np.array_equal(syn.i[lo:hi], pre[lo:hi])
        assert np.array_equal(syn.j[lo:hi], post[lo:hi])
        assert np.array_equal(syn.w_[lo:hi], np.asarray(weights[lo:hi] * p['w_syn']))
    lesion_edges = np.flatnonzero(pre == lesion)
    assert len(lesion_edges) > 0
    baseline_w = np.asarray(syn.w_[:]).copy()
    del pre, post, weights
    pois = []
    for i in exc:
        pois.append(PoissonInput(neu[i], 'v', N=1, rate=p['r_poi'], weight=p['w_syn'] * p['f_poi']))
        neu[i].rfc = 0 * ms
    counts = SpikeMonitor(neu, record=False)
    endpoint_mon = SpikeMonitor(neu[endpoint:endpoint+1], record=True)
    before = StateMonitor(neu, 'v', record=exc, when='before_synapses', name='input_before')
    after = StateMonitor(neu, 'v', record=exc, when='after_synapses', name='input_after')
    net = Network(neu, syn, counts, endpoint_mon, before, after, *pois)
    net.store('initial')
    return dict(net=net, neu=neu, syn=syn, counts=counts, endpoint_mon=endpoint_mon,
                before=before, after=after, ids=ids, exc=exc, endpoint=endpoint,
                lesion=lesion, lesion_edges=lesion_edges, baseline_w=baseline_w,
                amplitude=float(p['w_syn'] * p['f_poi']))


def initial_state(b):
    import numpy as np
    result = {key: digest_array(b['neu'].variables[key].get_value()) for key in
              ('v', 'g', 'rfc', 'lastspike', 'not_refractory', '_spikespace')}
    assert float(b['net'].t) == 0
    assert int(np.asarray(b['counts'].count).sum()) == 0
    assert len(b['endpoint_mon'].t) == len(b['before'].t) == len(b['after'].t) == 0
    result['time_seconds'] = float(b['net'].t)
    return result


def trial(b, trial_seed, gain, silenced, duration=1.0):
    import numpy as np
    from brian2 import seed, second
    b['net'].restore('initial', restore_random_state=True)
    state = initial_state(b)
    syn = b['syn']
    for lo in range(0, len(syn), 65536):
        hi = min(lo + 65536, len(syn))
        assert np.array_equal(syn.w_[lo:hi], b['baseline_w'][lo:hi])
        syn.w_[lo:hi] = b['baseline_w'][lo:hi] * gain
    if silenced:
        syn.w_[b['lesion_edges']] = 0
    # Verify every weight, including that no other edge has been silenced.
    for lo in range(0, len(syn), 65536):
        hi = min(lo + 65536, len(syn))
        expected = b['baseline_w'][lo:hi] * gain
        if silenced:
            edges = b['lesion_edges']
            local = edges[(edges >= lo) & (edges < hi)] - lo
            expected[local] = 0
        assert np.array_equal(syn.w_[lo:hi], expected)
    seed(trial_seed)
    start = time.monotonic()
    b['net'].run(duration * second)
    elapsed = time.monotonic() - start
    raw = (np.asarray(b['after'].v) - np.asarray(b['before'].v)) / b['amplitude']
    events = np.rint(raw).astype(np.uint8)
    assert np.all(np.abs(raw - events) < 1e-10)
    assert np.all(events <= 1)
    assert events.shape == (len(b['exc']), round(duration / .0001))
    counts = np.asarray(b['counts'].count).copy()
    times = np.asarray(b['endpoint_mon'].t / second).copy()
    assert float(b['net'].t / second) == duration
    assert len(times) == int(counts[b['endpoint']])
    return dict(seed=trial_seed, recurrent_gain=gain, silenced=silenced,
                duration_seconds=duration, dt_seconds=.0001,
                mn9_count=int(counts[b['endpoint']]), total_spikes=int(counts.sum()),
                mn9_times_seconds=times.tolist(), all_counts_sha256=digest_array(counts),
                input_sha256=digest_array(events), input_event_count=int(events.sum()),
                input_shape=list(events.shape), initial_state=state,
                weights_checked=len(syn), silenced_edge_count=len(b['lesion_edges']) if silenced else 0,
                simulation_seconds=elapsed), counts, events


def tiny_checks(out):
    if not __debug__:
        raise SystemExit('Refusing to run with assertions disabled')
    import numpy as np
    from brian2 import start_scope, ms, mV
    start_scope()
    b = build(tiny=True)
    base, counts, events = trial(b, 0, 1, False, .05)
    repeat, counts2, events2 = trial(b, 0, 1, False, .05)
    assert np.array_equal(counts, counts2) and np.array_equal(events, events2)
    assert base['mn9_times_seconds'] == repeat['mn9_times_seconds']
    changed, _, events3 = trial(b, 0, .8, True, .05)
    assert np.array_equal(events, events3) and base['initial_state'] == changed['initial_state']
    restored, counts4, events4 = trial(b, 0, 1, False, .05)
    assert np.array_equal(counts, counts4) and np.array_equal(events, events4)
    # Force an event with the 1.8 ms synaptic delay still pending, then restore.
    b['net'].restore('initial', restore_random_state=True)
    b['neu'].v[1] = -40 * mV
    b['net'].run(.1 * ms)
    assert int(b['counts'].count[1]) == 1
    assert float(b['net'].t / ms) == .1
    after_queue, counts5, events5 = trial(b, 0, 1, False, .05)
    assert np.array_equal(counts, counts5) and np.array_equal(events, events5)
    assert after_queue['mn9_times_seconds'] == base['mn9_times_seconds']
    # Observe-only input monitors can be disabled without changing neural output.
    b['before'].active = b['after'].active = False
    b['net'].restore('initial', restore_random_state=True)
    from brian2 import seed, second
    seed(0)
    b['net'].run(.05 * second)
    assert np.array_equal(counts, np.asarray(b['counts'].count))
    assert base['mn9_times_seconds'] == np.asarray(b['endpoint_mon'].t / second).tolist()
    assert counts[b['endpoint']] > 0
    receipt = dict(passed=True, restore_repeats_exactly=True, actual_inputs_match=True,
                   restore_after_silencing_exact=True, pending_delay_cleared=True,
                   observation_does_not_change_output=True, outgoing_only_weights_checked=True,
                   pending_spike_observed=True, runner_sha256=sha(Path(__file__)),
                   tiny_counts=counts.tolist(), utc=dt.datetime.now(dt.timezone.utc).isoformat())
    out.write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps(receipt), flush=True)


def main():
    if not __debug__:
        raise SystemExit('Refusing to run with assertions disabled')
    ap = argparse.ArgumentParser()
    ap.add_argument('--tiny', action='store_true')
    ap.add_argument('--preflight-only', action='store_true')
    ap.add_argument('--deadline-utc')
    ap.add_argument('--out', type=Path, default=HERE / 'results')
    args = ap.parse_args()
    if args.tiny:
        tiny_checks(HERE / 'tiny-checks.json')
        return
    import numpy as np
    protocol = json.loads((HERE / 'PROTOCOL.json').read_text())
    import importlib.metadata
    import platform
    assert platform.python_version() == protocol['python']
    for package, version in protocol['packages'].items():
        assert importlib.metadata.version(package) == version, package
    for rel, expected in protocol['sha256'].items():
        assert sha(ROOT / rel) == expected, rel
    tiny_receipt = json.loads((HERE / 'tiny-checks.json').read_text())
    assert tiny_receipt['passed']
    assert tiny_receipt['runner_sha256'] == sha(Path(__file__))
    deadline_value = dt.datetime.fromisoformat(args.deadline_utc)
    if deadline_value.utcoffset() != dt.timedelta(0):
        raise ValueError('deadline must be explicit UTC (+00:00 or Z)')
    deadline = deadline_value.timestamp()
    assert time.time() < deadline <= time.time() + protocol['maximum_attempt_seconds']
    out = args.out.resolve()
    assert out.is_relative_to(HERE), 'Outputs must stay in this experiment directory'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.mkdir(exist_ok=False)
    wd = Watchdog(str(out), deadline)
    reason = wd.sample()
    admission = protocol['admission_minimum_GiB']
    for key, minimum in admission.items():
        if wd.mins[key] < minimum * 2**30:
            reason = reason or f'Admission {key}: {wd.mins[key]} < {minimum} GiB'
    (out / 'attempt.json').write_text(json.dumps(dict(
        started_utc=dt.datetime.now(dt.timezone.utc).isoformat(), deadline_utc=args.deadline_utc,
        protocol_sha256=sha(HERE / 'PROTOCOL.json'), initial_resources=wd.mins,
        admitted=reason is None, pid=os.getpid()), indent=2))
    if args.preflight_only:
        wd.stop_reason = reason
        wd.write('refused_preflight' if reason else 'admitted_preflight_only')
        print(json.dumps(dict(admitted=reason is None, reason=reason, numerical_work=False)))
        return
    if reason:
        wd.stop_reason = reason
        wd.write('refused_preflight')
        raise RuntimeError(reason)
    lock = ROOT / 'feasibility-2026-10-13/numerical.lock'
    lock_acquired = False
    def save(label, result, counts, events):
        result['protocol_sha256'] = sha(HERE / 'PROTOCOL.json')
        (out / (label + '.json')).write_text(json.dumps(result, indent=2), encoding='utf-8')
        np.savez_compressed(out / (label + '.npz'), counts=counts, input_events=events)
        print(json.dumps({k: result[k] for k in ('seed', 'recurrent_gain', 'silenced', 'mn9_count', 'simulation_seconds')}), flush=True)
        wd.write(label)
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        lock_acquired = True
        with os.fdopen(fd, 'w') as lock_file:
            lock_file.write(str(os.getpid()))
        wd.start()
        print('Building one network and recording initial state', flush=True)
        b = build()
        historic = json.loads((ROOT / 'feasibility-2026-10-13/intact-seed0/counts.json').read_text())
        gate, counts, events = trial(b, 0, 1, False)
        expected = np.zeros(len(b['ids']), dtype=counts.dtype)
        lookup = {int(x): i for i, x in enumerate(b['ids'])}
        for flyid, count in historic['nonzero'].items():
            expected[lookup[int(flyid)]] = count
        assert np.array_equal(counts, expected)
        assert gate['mn9_times_seconds'] == historic['mn9_times_seconds']
        save('gate-intact', gate, counts, events)
        repeat, count2, event2 = trial(b, 0, 1, False)
        assert np.array_equal(counts, count2) and np.array_equal(events, event2)
        assert gate['mn9_times_seconds'] == repeat['mn9_times_seconds']
        assert gate['initial_state'] == repeat['initial_state']
        save('gate-repeat', repeat, count2, event2)
        (out / 'gate.json').write_text(json.dumps(dict(passed=True, historical_all_counts_exact=True,
            historical_mn9_times_exact=True, repeated_all_counts_times_inputs_exact=True), indent=2))
        summaries = []
        seed_inputs = {}
        for gain in protocol['recurrent_gains']:
            for trial_seed in protocol['seeds']:
                pair = []
                for silenced in (False, True):
                    result, counts, events = trial(b, trial_seed, gain, silenced)
                    assert result['initial_state'] == gate['initial_state']
                    if trial_seed in seed_inputs:
                        assert np.array_equal(events, seed_inputs[trial_seed])
                    else:
                        seed_inputs[trial_seed] = events.copy()
                    label = f'gain-{gain:.1f}_seed-{trial_seed}_' + ('silenced' if silenced else 'intact')
                    save(label, result, counts, events)
                    pair.append(result)
                summaries.append(dict(gain=gain, seed=trial_seed, intact=pair[0]['mn9_count'],
                    silenced=pair[1]['mn9_count'], difference=pair[1]['mn9_count']-pair[0]['mn9_count'],
                    ratio=pair[1]['mn9_count']/pair[0]['mn9_count'] if pair[0]['mn9_count'] else None,
                    input_sha256=pair[0]['input_sha256']))
                (out / 'pairs.json').write_text(json.dumps(summaries, indent=2), encoding='utf-8')
        (out / 'completion.json').write_text(json.dumps(dict(complete=True, pairs=len(summaries),
             trials=len(summaries)*2, utc=dt.datetime.now(dt.timezone.utc).isoformat(),
             biological_validation=False, protocol_sha256=sha(HERE/'PROTOCOL.json')), indent=2))
        wd.write('completed')
    except Exception as exc:
        (out / 'failure.json').write_text(json.dumps(dict(type=type(exc).__name__, message=str(exc),
            utc=dt.datetime.now(dt.timezone.utc).isoformat(), complete=False), indent=2))
        raise
    finally:
        if lock_acquired and lock.exists() and lock.read_text() == str(os.getpid()):
            lock.unlink()


if __name__ == '__main__':
    main()
