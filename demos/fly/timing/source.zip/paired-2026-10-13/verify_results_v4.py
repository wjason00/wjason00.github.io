"""Independent saved-output verification for v4; never imports a simulation runner.

Writes only new verification-v4.json and paired-results-v4.csv in the attempt.
An incomplete or failed attempt gets a failed receipt accounting for all 30 cells.
"""
import argparse
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
GAINS = (1., .8, 1.2)
SEEDS = (0, 1, 2, 3, 4)
STATE = ('v', 'g', 'rfc', 'lastspike', 'not_refractory', '_spikespace')
N, EDGES, TICKS, INPUTS = 127400, 14687178, 10000, 21
COMMON = {'counts', 'mn9_times_seconds', 'before_v', 'after_v', 'eligible'} | {'final_' + key for key in STATE}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def array_sha(array):
    # Compatible encoding, implemented here rather than imported from the runner.
    return hashlib.sha256(str(array.dtype).encode() + str(array.shape).encode()
                          + array.tobytes(order='C')).hexdigest()


def read_json(path):
    def invalid_constant(value):
        raise ValueError(f'Nonfinite JSON constant: {value}')
    return json.loads(Path(path).read_text(encoding='utf-8'), parse_constant=invalid_constant)


def cell_records(out):
    cells = []
    for gain in GAINS:
        for seed in SEEDS:
            for condition in ('intact', 'silenced'):
                label = f'gain-{gain:.1f}_seed-{seed}_{condition}'
                present = {suffix: (out / (label + suffix)).is_file() for suffix in ('.json', '.npz')}
                cells.append({'label': label, 'gain': gain, 'seed': seed, 'condition': condition,
                              'files_present': present,
                              'status': 'not_verified' if all(present.values()) else 'missing_evidence'})
    return cells


def verify(out, report):
    import numpy as np
    protocol_path = HERE / 'PROTOCOL-v4.json'
    protocol_hash = sha(protocol_path)
    protocol = read_json(protocol_path)
    require(protocol['recurrent_gains'] == list(GAINS) and protocol['seeds'] == list(SEEDS), 'Frozen grid changed')
    require(protocol['planned_trials'] == 30 and protocol['duration_seconds'] == 1., 'Trial/duration contract changed')
    require(protocol['dt_seconds'] == .0001 and protocol['stimulus_hz'] == 100, 'Input time/rate contract changed')
    require(protocol['mn9_id'] == 720575940660219265 and protocol['silenced_id'] == 720575940623211725,
            'Endpoint or lesion identity changed')
    require(protocol['external_amplitude_volts'] == .06875, 'External amplitude changed')
    report['protocol_sha256'] = protocol_hash
    report['source_hashes'] = {}
    for relative, expected in protocol['sha256'].items():
        path = (ROOT / relative).resolve()
        require(path.is_relative_to(ROOT.resolve()), f'Source path escapes project: {relative}')
        actual = sha(path)
        require(actual == expected, f'Frozen source fingerprint mismatch: {relative}')
        report['source_hashes'][relative] = actual
    required_sources = {'paired_runner_v4.py', 'verify_results_v4.py', 'candidate_drive.py',
                        'reference_drive.py', 'model.py', 'loader.py'}
    require(required_sources <= {Path(name).name for name in protocol['sha256']}, 'Protocol omits a required source')
    fixture_path = (ROOT / protocol['fixture_receipt']).resolve()
    require(fixture_path.is_relative_to(ROOT.resolve()), 'Fixture path escapes project')
    fixture = read_json(fixture_path)
    require(fixture['status'] == 'passed_small_network_only' and len(fixture['comparisons']) == 48,
            'Required small-network fixture is not complete')
    for relative, expected in fixture['source_hashes'].items():
        require(sha(ROOT / relative) == expected, f'Fixture source drift: {relative}')
    report['fixture_sha256'] = sha(fixture_path)
    report['result_files_sha256'] = {}

    def bind_file(name):
        report['result_files_sha256'][name] = sha(out / name)

    identity = read_json(out / 'identity.json')
    with np.load(out / 'network_identity.npz', allow_pickle=False) as saved:
        require(set(saved.files) == {'ids', 'exc', 'lesion_edges'}, 'Unexpected network identity fields')
        ids, exc, lesion_edges = (saved[key].copy() for key in ('ids', 'exc', 'lesion_edges'))
    for name, value, length in (('ids', ids, N), ('exc', exc, INPUTS)):
        require(value.shape == (length,) and np.issubdtype(value.dtype, np.integer), f'Invalid {name} identity array')
        require(len(np.unique(value)) == length, f'Duplicate {name} identity')
    require(np.all((exc >= 0) & (exc < N)), 'Input indices outside neuron array')
    require(identity['neuron_count'] == N and identity['recurrent_edges'] == EDGES, 'Network size changed')
    require(identity['ordered_input_indices'] == exc.tolist(), 'Ordered input index identity differs')
    require(identity['ordered_input_flywire_ids'] == ids[exc].tolist(), 'Ordered input FlyWire identity differs')
    require(identity['amplitude_volts'] == protocol['external_amplitude_volts'], 'Identity amplitude differs')
    endpoint, lesion = identity['endpoint'], identity['lesion']
    require(type(endpoint) is int and type(lesion) is int and 0 <= endpoint < N and 0 <= lesion < N,
            'Invalid endpoint/lesion indices')
    require(int(ids[endpoint]) == protocol['mn9_id'] and int(ids[lesion]) == protocol['silenced_id'],
            'Endpoint/lesion index-to-ID mapping differs')
    with (ROOT / 'upstream/shiu_91bdd1e/2023_03_23_completeness_630_final.csv').open(newline='', encoding='utf-8') as stream:
        reader = csv.reader(stream)
        next(reader)
        source_ids = np.fromiter((int(row[0]) for row in reader), dtype=np.int64)
    require(np.array_equal(ids, source_ids), 'Neuron row order differs from pinned completeness data')
    original = read_json(ROOT / 'PROTOCOL.json')
    require(identity['ordered_input_flywire_ids'] == [int(value) for value in original['inputs']['stimulated_neurons']],
            'Stimulus order differs from the original frozen IDs')
    require(lesion_edges.ndim == 1 and np.issubdtype(lesion_edges.dtype, np.integer)
            and len(lesion_edges) > 0 and np.all((lesion_edges >= 0) & (lesion_edges < EDGES))
            and np.all(np.diff(lesion_edges) > 0), 'Invalid ordered outgoing-edge indices')
    require(identity['lesion_edges'] == len(lesion_edges), 'Lesion edge count differs')
    # Independently recover outgoing-edge row identities in bounded batches.
    import pyarrow.parquet as pq
    parquet = pq.ParquetFile(ROOT / 'upstream/shiu_91bdd1e/2023_03_23_connectivity_630_final.parquet')
    source_lesion, offset = [], 0
    for batch in parquet.iter_batches(columns=['Presynaptic_Index'], batch_size=131072):
        values = batch.column(0).to_numpy(zero_copy_only=False)
        source_lesion.append(np.flatnonzero(values == lesion) + offset)
        offset += len(values)
    require(offset == EDGES and np.array_equal(np.concatenate(source_lesion), lesion_edges),
            'Saved lesion edges differ from the pinned outgoing-edge rows')
    bind_file('identity.json'); bind_file('network_identity.npz')
    report['network_identity'] = identity

    initial = None
    schedule_hashes = {}
    amplitude = identity['amplitude_volts']

    def check_trial(label, seed, gain, silenced, mode):
        nonlocal initial
        record = read_json(out / (label + '.json'))
        require(record['mode'] == mode and type(record['seed']) is int and record['seed'] == seed
                and record['recurrent_gain'] == gain and record['silenced'] is silenced, f'{label}: trial identity differs')
        require(record['duration_seconds'] == 1. and record['final_time_seconds'] == 1.
                and record['dt_seconds'] == .0001, f'{label}: simulation time differs')
        require(record['protocol_sha256'] == protocol_hash, f'{label}: protocol hash differs')
        require(record['weights_checked'] == EDGES and record['silenced_edge_count'] == (len(lesion_edges) if silenced else 0),
                f'{label}: checked weight/lesion count differs')
        require(set(record['initial_state']) == set(STATE) | {'time_seconds'}
                and record['initial_state']['time_seconds'] == 0, f'{label}: initial-state contract differs')
        require(all(isinstance(record['initial_state'][key], str) and len(record['initial_state'][key]) == 64 for key in STATE),
                f'{label}: invalid initial-state fingerprints')
        if initial is None:
            initial = record['initial_state']
        require(record['initial_state'] == initial, f'{label}: initial state differs')
        keys = set(COMMON)
        if mode != 'historical':
            keys |= {'candidates', 'applied'}
        if mode == 'candidate':
            keys |= {'seen', 'drive_eligible'}
        with np.load(out / (label + '.npz'), allow_pickle=False) as saved:
            require(set(saved.files) == keys, f'{label}: array inventory differs')
            arrays = {key: saved[key].copy() for key in keys}
        require(set(record['arrays_sha256']) == keys, f'{label}: array fingerprint inventory differs')
        for key, array in arrays.items():
            require(array_sha(array) == record['arrays_sha256'][key], f'{label}: array hash differs: {key}')
        counts, times = arrays['counts'], arrays['mn9_times_seconds']
        require(counts.shape == (N,) and np.issubdtype(counts.dtype, np.integer)
                and np.all((counts >= 0) & (counts <= TICKS)), f'{label}: invalid counts')
        require(times.ndim == 1 and times.dtype == np.float64 and np.isfinite(times).all()
                and np.all((times >= 0) & (times < 1.)) and np.all(np.diff(times) > 0), f'{label}: invalid endpoint times')
        require(type(record['mn9_count']) is int and type(record['total_spikes']) is int
                and int(counts[endpoint]) == record['mn9_count'] == len(times)
                and int(counts.sum()) == record['total_spikes'], f'{label}: count summaries differ')
        for key in ('before_v', 'after_v'):
            require(arrays[key].shape == (TICKS, INPUTS) and arrays[key].dtype == np.float64
                    and np.isfinite(arrays[key]).all(), f'{label}: invalid {key}')
        mask = arrays['eligible']
        require(mask.shape == (TICKS, INPUTS) and mask.dtype == np.bool_, f'{label}: invalid eligibility mask')
        for key in STATE:
            array = arrays['final_' + key]
            if key == '_spikespace':
                require(array.shape == (N + 1,) and np.issubdtype(array.dtype, np.integer)
                        and 0 <= int(array[-1]) <= N, f'{label}: invalid final spike space')
            elif key == 'not_refractory':
                require(array.shape == (N,) and array.dtype == np.bool_, f'{label}: invalid final eligibility')
            else:
                require(array.shape == (N,) and array.dtype == np.float64 and not np.isnan(array).any()
                        and not np.isposinf(array).any(), f'{label}: invalid final {key}')
                if key != 'lastspike':
                    require(np.isfinite(array).all(), f'{label}: nonfinite final {key}')
        require(np.all(arrays['final_rfc'][exc] == 0), f'{label}: stimulated-neuron refractory duration changed')
        if mode == 'historical':
            delta = (arrays['after_v'] - arrays['before_v']) / amplitude
            applied = np.rint(delta)
            require(np.isin(applied, [0., 1.]).all() and np.all(applied[~mask] == 0),
                    f'{label}: historical increment is not a gated binary event')
            expected_v = arrays['before_v'].copy()
            expected_v[mask] += amplitude * applied[mask]
            require(np.array_equal(arrays['after_v'], expected_v), f'{label}: historical voltage increment differs')
        else:
            candidates, applied = arrays['candidates'], arrays['applied']
            for key, array in (('candidates', candidates), ('applied', applied)):
                require(array.shape == (TICKS, INPUTS) and array.dtype == np.uint8
                        and np.isin(array, [0, 1]).all(), f'{label}: invalid binary {key}')
            rng = np.random.Generator(np.random.PCG64(seed))
            regenerated = rng.binomial(1, protocol['stimulus_hz'] * protocol['dt_seconds'],
                                      size=(TICKS, INPUTS)).astype(np.uint8)
            require(np.array_equal(candidates, regenerated), f'{label}: private PCG64 candidates differ')
            require(np.array_equal(applied, candidates * mask), f'{label}: candidate acceptance differs')
            expected_v = arrays['before_v'].copy()
            expected_v[mask] += amplitude * candidates[mask]
            require(np.array_equal(arrays['after_v'], expected_v), f'{label}: exact voltage reconstruction failed')
            manifest = {'array_sha256': array_sha(candidates), 'ordered_input_indices': exc.tolist(),
                        'ordered_input_flywire_ids': ids[exc].tolist(), 'seed': seed, 'rate_hz': 100.,
                        'dt_seconds': .0001, 'generator': 'numpy.random.Generator(numpy.random.PCG64(seed))',
                        'orientation': 'time-by-ordered-input'}
            identity_hash = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
            require(seed not in schedule_hashes or schedule_hashes[seed]['identity_sha256'] == identity_hash,
                    f'{label}: cross-condition candidate/mapping identity differs')
            schedule_hashes[seed] = dict(manifest, identity_sha256=identity_hash)
            if mode == 'candidate':
                require(arrays['seen'].shape == (TICKS,) and arrays['seen'].dtype == np.bool_ and arrays['seen'].all(),
                        f'{label}: incomplete candidate tick coverage')
                require(arrays['drive_eligible'].dtype == np.bool_ and np.array_equal(arrays['drive_eligible'], mask),
                        f'{label}: drive eligibility differs from independent observation')
        bind_file(label + '.json'); bind_file(label + '.npz')
        return record, arrays

    historic, historical_arrays = check_trial('gate-historical', 0, 1., False, 'historical')
    original_counts = read_json(ROOT / 'feasibility-2026-10-13/intact-seed0/counts.json')
    expected_counts = np.zeros(N, dtype=np.int64)
    lookup = {int(value): index for index, value in enumerate(ids)}
    for fly_id, count in original_counts['nonzero'].items():
        expected_counts[lookup[int(fly_id)]] = count
    require(np.array_equal(historical_arrays['counts'], expected_counts)
            and historical_arrays['mn9_times_seconds'].tolist() == original_counts['mn9_times_seconds'],
            'Historical Poisson gate does not reproduce saved counts/times')
    del historical_arrays
    base, baseline_arrays = check_trial('gate-candidate', 0, 1., False, 'candidate')
    compare = COMMON | {'candidates', 'applied'}
    for label, mode in (('gate-reference', 'reference'), ('gate-repeat', 'candidate')):
        record, arrays = check_trial(label, 0, 1., False, mode)
        for key in compare:
            require(arrays[key].dtype == baseline_arrays[key].dtype and np.array_equal(arrays[key], baseline_arrays[key]),
                    f'{label}: candidate/reference/repeat mismatch in {key}')
    generated = read_json(out / 'reference-generated-code.json')
    require(len(generated) == INPUTS and set(generated) == {f'reference_input_{i}' for i in range(INPUTS)},
            'Whole-brain reference runner inventory differs')
    require(all(isinstance(code, str) and 'v[not_refractory]' in code for code in generated.values()),
            'Reference generated code does not expose conditional voltage writes')
    gate = read_json(out / 'gate.json')
    for key in ('passed', 'historical_all_counts_times_exact', 'new_coupling_reference_repeat_exact',
                'exact_candidate_mask_voltage_reconstruction'):
        require(gate[key] is True, f'Gate not passed: {key}')
    require(gate['protocol_sha256'] == protocol_hash, 'Gate protocol hash differs')
    bind_file('reference-generated-code.json'); bind_file('gate.json')
    report['gates_independently_verified'] = True

    rows, trial_counts = [], {}
    for cell in report['cells']:
        try:
            record, arrays = check_trial(cell['label'], cell['seed'], cell['gain'], cell['condition'] == 'silenced', 'candidate')
            if cell['gain'] == 1. and cell['seed'] == 0 and cell['condition'] == 'intact':
                for key in baseline_arrays:
                    require(np.array_equal(arrays[key], baseline_arrays[key]), f'Grid baseline differs from candidate gate: {key}')
            trial_counts[cell['label']] = record['mn9_count']
            cell.update(status='verified', mn9_count=record['mn9_count'])
        except Exception as error:
            cell.update(status='failed', error=f'{type(error).__name__}: {error}')
            raise
    for gain in GAINS:
        for seed in SEEDS:
            prefix = f'gain-{gain:.1f}_seed-{seed}_'
            intact, silenced = trial_counts[prefix + 'intact'], trial_counts[prefix + 'silenced']
            rows.append({'gain': gain, 'seed': seed, 'intact': intact, 'silenced': silenced,
                         'difference': silenced - intact, 'ratio': silenced / intact if intact else None})
    require(read_json(out / 'pairs.json') == rows, 'Saved paired table differs from independent recomputation')
    complete = read_json(out / 'completion.json')
    require(complete['complete'] is True and complete['trials'] == 30 and complete['pairs'] == 15
            and complete['protocol_sha256'] == protocol_hash and complete['biological_validation'] is False,
            'Completion contract differs')
    require(not (out / 'failure.json').exists(), 'Attempt has a failure record')
    expected_labels = {cell['label'] for cell in report['cells']} | {'gate-historical', 'gate-candidate', 'gate-reference', 'gate-repeat'}
    for suffix in ('.json', '.npz'):
        found = {path.stem for path in out.glob('*' + suffix) if path.stem.startswith(('gain-', 'gate-'))}
        require(found == expected_labels, f'Trial file inventory differs for {suffix}')
    bind_file('pairs.json'); bind_file('completion.json')
    require(len({value['array_sha256'] for value in schedule_hashes.values()}) == 5, 'Input seeds are not distinct')
    report['candidate_manifests'] = schedule_hashes
    report['summary'] = []
    for gain in GAINS:
        group = [row for row in rows if row['gain'] == gain]
        ratios = [row['ratio'] for row in group if row['ratio'] is not None]
        sum_intact = sum(row['intact'] for row in group)
        sum_silenced = sum(row['silenced'] for row in group)
        report['summary'].append({'recurrent_gain': gain, 'n_input_seeds': 5,
            'intact_mean_spikes_per_second': sum_intact / 5., 'silenced_mean_spikes_per_second': sum_silenced / 5.,
            'paired_mean_difference_spikes_per_second': (sum_silenced - sum_intact) / 5.,
            'ratio_of_means': sum_silenced / sum_intact if sum_intact else None,
            'individual_ratio_range': [min(ratios), max(ratios)] if ratios else None,
            'undefined_ratio_seeds': [row['seed'] for row in group if row['ratio'] is None]})
    for name, expected in report['result_files_sha256'].items():
        require(sha(out / name) == expected, f'Result file changed during verification: {name}')
    require(sha(protocol_path) == protocol_hash, 'Protocol changed during verification')
    for relative, expected in report['source_hashes'].items():
        require(sha(ROOT / relative) == expected, f'Source changed during verification: {relative}')
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    require(out.is_dir(), 'Attempt directory does not exist')
    receipt = out / 'verification-v4.json'
    table = out / 'paired-results-v4.csv'
    require(not receipt.exists() and not table.exists(), 'Verification outputs already exist; preserve previous evidence')
    report = {'passed': False, 'status': 'incomplete', 'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'verifier_sha256': sha(__file__), 'cells': cell_records(out), 'biological_validation': False,
              'scope': 'saved v4 whole-brain evidence; five stochastic input seeds, one model/frequency/endpoint',
              'applied_inputs_need_not_match_between_conditions': True}
    try:
        rows = verify(out, report)
        with table.open('x', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
        report.update(passed=True, status='complete_saved_output_verification', pairs=rows,
                      table_sha256=sha(table), every_seed_candidate_identity_matches_all_six_conditions=True)
    except Exception as error:
        report.update(status='failed_saved_output_verification', error=f'{type(error).__name__}: {error}',
                      traceback=traceback.format_exc())
    report['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
    receipt.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({key: report.get(key) for key in ('passed', 'status', 'error', 'summary')}, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
