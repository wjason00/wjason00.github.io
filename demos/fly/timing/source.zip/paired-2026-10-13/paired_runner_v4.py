"""V4 candidate-coupled experiment; historical Poisson gate remains separate."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import time

for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
IMPL = ROOT / 'feasibility-2026-10-13/implementation'
UP = ROOT / 'upstream/shiu_91bdd1e'
sys.path.insert(0, str(IMPL))
sys.path.insert(0, str(UP))
from runner import Watchdog, sha
sys.path.insert(0, str(HERE / 'candidate-input-prototype'))


def digest_array(a):
    import numpy as np
    a = np.ascontiguousarray(a)
    return hashlib.sha256(str(a.dtype).encode() + str(a.shape).encode() + a.tobytes()).hexdigest()


def build(tiny=False):
    import numpy as np
    import pandas as pd
    from brian2 import (NeuronGroup, Synapses, PoissonInput, SpikeMonitor,
                        StateMonitor, Network, seed, defaultclock, prefs, ms, Hz)
    import model as up
    from loader import load_edges
    prefs.codegen.target = 'numpy'
    seed(0)
    defaultclock.dt = .1 * ms
    p = dict(up.default_params)
    p['r_poi'] = 100 * Hz
    if tiny:
        ids = np.arange(4, dtype=np.int64)
        pre = np.array([0, 1, 1, 2, 3], dtype=np.int32)
        post = np.array([1, 2, 3, 3, 2], dtype=np.int32)
        weights = np.array([400, 250, 150, 100, -20], dtype=np.int32)
        exc, endpoint, lesion = [0], 3, 1
    else:
        proto = json.loads((ROOT / 'PROTOCOL.json').read_text())
        comp = pd.read_csv(UP / '2023_03_23_completeness_630_final.csv', index_col=0)
        ids = comp.index.to_numpy(dtype=np.int64)
        assert len(ids) == len(np.unique(ids)) == 127400
        lookup = {int(x): i for i, x in enumerate(ids)}
        exc = [lookup[int(x)] for x in proto['inputs']['stimulated_neurons']]
        assert len(exc) == len(set(exc)) == 21
        endpoint = lookup[720575940660219265]
        lesion = lookup[720575940623211725]
        pre, post, weights = load_edges(UP / '2023_03_23_connectivity_630_final.parquet', len(ids), batch_size=131072)
        assert len(pre) == len(post) == len(weights) == 14687178
    neu = NeuronGroup(len(ids), p['eqs'], method='linear', threshold=p['eq_th'], reset=p['eq_rst'],
                      refractory='rfc', name='default_neurons', namespace=p)
    neu.v = p['v_0']
    neu.g = 0
    neu.rfc = p['t_rfc']
    syn = Synapses(neu, neu, 'w : volt', on_pre='g += w', delay=p['t_dly'], name='default_synapses')
    syn.connect(i=pre, j=post)
    syn.w = weights * p['w_syn']
    for lo in range(0, len(pre), 65536):
        hi = min(lo + 65536, len(pre))
        assert np.array_equal(syn.i[lo:hi], pre[lo:hi])
        assert np.array_equal(syn.j[lo:hi], post[lo:hi])
        assert np.array_equal(syn.w_[lo:hi], np.asarray(weights[lo:hi] * p['w_syn']))
    lesion_edges = np.flatnonzero(pre == lesion)
    assert len(lesion_edges) > 0
    baseline_w = np.asarray(syn.w_[:]).copy()
    del pre, post, weights
    pois = []
    for i in exc:
        pois.append(PoissonInput(neu[i], 'v', N=1, rate=p['r_poi'], weight=p['w_syn'] * p['f_poi']))
        neu[i].rfc = 0 * ms
    counts = SpikeMonitor(neu, record=False)
    endpoint_mon = SpikeMonitor(neu[endpoint:endpoint+1], record=True)
    before = StateMonitor(neu, ['v', 'not_refractory'], record=exc, when='before_synapses', name='input_before')
    after = StateMonitor(neu, 'v', record=exc, when='after_synapses', name='input_after')
    from candidate_drive import CandidateDrive
    from reference_drive import ReferenceDrive
    drive = CandidateDrive(neu, exc, float(p['w_syn'] * p['f_poi']))
    operation = drive.operation()
    reference = ReferenceDrive(neu, exc, p['w_syn'] * p['f_poi'], neu.clock.dt)
    operation.active = False
    for item in reference.runners:
        item.active = False
    net = Network(neu, syn, counts, endpoint_mon, before, after, *pois,
                  operation, *reference.runners)
    net.store('initial')
    return dict(net=net, neu=neu, syn=syn, counts=counts, endpoint_mon=endpoint_mon,
                drive=drive, operation=operation, reference=reference, pois=pois,
                before=before, after=after, ids=ids, exc=exc, endpoint=endpoint,
                lesion=lesion, lesion_edges=lesion_edges, baseline_w=baseline_w,
                amplitude=float(p['w_syn'] * p['f_poi']))


def initial_state(b):
    import numpy as np
    result = {key: digest_array(b['neu'].variables[key].get_value()) for key in
              ('v', 'g', 'rfc', 'lastspike', 'not_refractory', '_spikespace')}
    assert float(b['net'].t) == 0
    assert int(np.asarray(b['counts'].count).sum()) == 0
    assert len(b['endpoint_mon'].t) == len(b['before'].t) == len(b['after'].t) == 0
    result['time_seconds'] = float(b['net'].t)
    return result


STATE = ('v', 'g', 'rfc', 'lastspike', 'not_refractory', '_spikespace')


def trial(b, trial_seed, gain, silenced, mode, duration=1.0):
    import numpy as np
    from brian2 import seed, second
    from candidate_drive import make_candidates
    b['net'].restore('initial', restore_random_state=True)
    state = initial_state(b)
    for item in b['pois']:
        item.active = mode == 'historical'
    b['operation'].active = mode == 'candidate'
    for item in b['reference'].runners:
        item.active = mode == 'reference'
    assert mode in ('historical', 'candidate', 'reference')
    syn = b['syn']
    for lo in range(0, len(syn), 65536):
        hi = min(lo + 65536, len(syn))
        assert np.array_equal(syn.w_[lo:hi], b['baseline_w'][lo:hi])
        expected = b['baseline_w'][lo:hi] * gain
        if silenced:
            edges = b['lesion_edges']
            expected[edges[(edges >= lo) & (edges < hi)] - lo] = 0
        syn.w_[lo:hi] = expected
        assert np.array_equal(syn.w_[lo:hi], expected)
    candidates = None
    if mode != 'historical':
        candidates = make_candidates(trial_seed, round(duration / .0001), len(b['exc']),
                                     rate_hz=100., dt_seconds=.0001)
        if mode == 'candidate':
            b['drive'].arm(candidates)
        else:
            b['reference'].arm(candidates, duration_seconds=duration)
    seed(trial_seed)
    start = time.monotonic()
    b['net'].run(duration * second)
    elapsed = time.monotonic() - start
    arrays = dict(counts=np.asarray(b['counts'].count).copy(),
                  mn9_times_seconds=np.asarray(b['endpoint_mon'].t / second).copy(),
                  before_v=np.asarray(b['before'].v).T.copy(),
                  after_v=np.asarray(b['after'].v).T.copy(),
                  eligible=np.asarray(b['before'].not_refractory).T.copy())
    arrays.update({'final_' + key: b['neu'].variables[key].get_value().copy() for key in STATE})
    if mode != 'historical':
        arrays['candidates'] = candidates.copy()
        arrays['applied'] = (b['drive'].applied.copy() if mode == 'candidate'
                             else candidates * arrays['eligible'])
        if mode == 'candidate':
            arrays['seen'] = b['drive'].seen.copy()
            arrays['drive_eligible'] = b['drive'].eligible.copy()
    result = dict(seed=trial_seed, recurrent_gain=gain, silenced=silenced, mode=mode,
                  duration_seconds=duration, dt_seconds=.0001,
                  mn9_count=int(arrays['counts'][b['endpoint']]),
                  total_spikes=int(arrays['counts'].sum()), initial_state=state,
                  arrays_sha256={key: digest_array(value) for key, value in arrays.items()},
                  weights_checked=len(syn), silenced_edge_count=len(b['lesion_edges']) if silenced else 0,
                  final_time_seconds=float(b['net'].t / second), simulation_seconds=elapsed)
    return result, arrays


def validate(b, result, arrays):
    import numpy as np
    ticks = round(result['duration_seconds'] / result['dt_seconds'])
    assert result['final_time_seconds'] == result['duration_seconds']
    assert len(arrays['mn9_times_seconds']) == result['mn9_count']
    for key in ('before_v', 'after_v', 'eligible'):
        assert arrays[key].shape == (ticks, len(b['exc'])), key
    if result['mode'] != 'historical':
        assert np.array_equal(arrays['applied'], arrays['candidates'] * arrays['eligible'])
        expected = arrays['before_v'].copy()
        mask = arrays['eligible']
        expected[mask] += b['amplitude'] * arrays['candidates'][mask]
        assert np.array_equal(arrays['after_v'], expected), 'Exact applied-voltage reconstruction failed'
        if result['mode'] == 'candidate':
            assert arrays['seen'].all()
            assert np.array_equal(arrays['drive_eligible'], arrays['eligible'])
            b['drive'].check_complete(arrays['applied'])
        else:
            b['reference'].check_complete()


def main():
    if not __debug__:
        raise SystemExit('Refusing to run with assertions disabled')
    ap = argparse.ArgumentParser()
    ap.add_argument('--deadline-utc', required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    protocol_path = HERE / 'PROTOCOL-v4.json'
    protocol = json.loads(protocol_path.read_text())
    deadline_value = dt.datetime.fromisoformat(args.deadline_utc)
    if deadline_value.utcoffset() != dt.timedelta(0):
        raise ValueError('deadline must be explicit UTC')
    deadline = deadline_value.timestamp()
    assert time.time() < deadline <= time.time() + protocol['maximum_attempt_seconds']
    out = args.out.resolve()
    assert out.is_relative_to(HERE)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.mkdir(exist_ok=False)
    wd = Watchdog(str(out), deadline)
    reason = wd.sample()
    for key, minimum in protocol['admission_minimum_GiB'].items():
        if wd.mins[key] < minimum * 2**30:
            reason = reason or f'Admission {key}: {wd.mins[key]} < {minimum} GiB'
    protocol_sha = sha(protocol_path)
    (out / 'attempt.json').write_text(json.dumps(dict(
        started_utc=dt.datetime.now(dt.timezone.utc).isoformat(), deadline_utc=args.deadline_utc,
        protocol_sha256=protocol_sha, initial_resources=wd.mins,
        admitted=reason is None, pid=os.getpid()), indent=2))
    if reason:
        wd.stop_reason = reason
        wd.write('refused_preflight')
        raise RuntimeError(reason)
    lock = ROOT / 'feasibility-2026-10-13/numerical.lock'
    lock_acquired = False
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        lock_acquired = True
        with os.fdopen(fd, 'w') as f:
            f.write(str(os.getpid()))
        wd.start()
        import importlib.metadata
        import platform
        assert platform.python_version() == protocol['python']
        for package, version in protocol['packages'].items():
            assert importlib.metadata.version(package) == version, package
        for rel, expected in protocol['sha256'].items():
            assert sha(ROOT / rel) == expected, rel
        fixture = json.loads((ROOT / protocol['fixture_receipt']).read_text())
        assert fixture['status'] == 'passed_small_network_only'
        for rel, expected in fixture['source_hashes'].items():
            assert sha(ROOT / rel) == expected, rel
        import numpy as np
        def save(label, result, arrays):
            result['protocol_sha256'] = protocol_sha
            # Save raw evidence first; a gate failure must not discard simulated arrays.
            np.savez_compressed(out / (label + '.npz'), **arrays)
            (out / (label + '.json')).write_text(json.dumps(result, indent=2))
            print(json.dumps(dict(label=label, mn9_count=result['mn9_count'],
                                  simulation_seconds=result['simulation_seconds'])), flush=True)
            wd.write(label)
        print('Building one network with separately activated historical/candidate/reference inputs', flush=True)
        b = build()
        assert b['amplitude'] == protocol['external_amplitude_volts']
        identity = dict(endpoint=int(b['endpoint']), lesion=int(b['lesion']),
                        ordered_input_indices=[int(x) for x in b['exc']],
                        ordered_input_flywire_ids=[int(b['ids'][x]) for x in b['exc']],
                        amplitude_volts=b['amplitude'], neuron_count=len(b['ids']),
                        recurrent_edges=len(b['syn']), lesion_edges=len(b['lesion_edges']))
        np.savez_compressed(out / 'network_identity.npz', ids=b['ids'], exc=np.asarray(b['exc']),
                            lesion_edges=b['lesion_edges'])
        (out / 'identity.json').write_text(json.dumps(identity, indent=2))
        historic = json.loads((ROOT / 'feasibility-2026-10-13/intact-seed0/counts.json').read_text())
        gate, arrays = trial(b, 0, 1., False, 'historical')
        save('gate-historical', gate, arrays)
        validate(b, gate, arrays)
        expected = np.zeros(len(b['ids']), dtype=arrays['counts'].dtype)
        lookup = {int(x): i for i, x in enumerate(b['ids'])}
        for flyid, count in historic['nonzero'].items():
            expected[lookup[int(flyid)]] = count
        assert np.array_equal(arrays['counts'], expected)
        assert arrays['mn9_times_seconds'].tolist() == historic['mn9_times_seconds']
        base, base_arrays = trial(b, 0, 1., False, 'candidate')
        save('gate-candidate', base, base_arrays)
        validate(b, base, base_arrays)
        assert base['initial_state'] == gate['initial_state']
        for label, mode in (('gate-reference', 'reference'), ('gate-repeat', 'candidate')):
            other, other_arrays = trial(b, 0, 1., False, mode)
            save(label, other, other_arrays)
            if mode == 'reference':
                generated = b['reference'].generated_code()
                (out / 'reference-generated-code.json').write_text(json.dumps(generated, indent=2))
                assert len(generated) == len(b['exc'])
                assert all('not_refractory' in code for code in generated.values())
            validate(b, other, other_arrays)
            assert base['initial_state'] == other['initial_state']
            for key in ('counts', 'mn9_times_seconds', 'before_v', 'after_v', 'eligible',
                        'candidates', 'applied', *('final_' + key for key in STATE)):
                assert np.array_equal(base_arrays[key], other_arrays[key]), (label, key)
        (out / 'gate.json').write_text(json.dumps(dict(passed=True,
            historical_all_counts_times_exact=True, new_coupling_reference_repeat_exact=True,
            exact_candidate_mask_voltage_reconstruction=True, protocol_sha256=protocol_sha), indent=2))
        pairs = []
        seed_candidates = {}
        for gain in protocol['recurrent_gains']:
            for trial_seed in protocol['seeds']:
                pair = []
                for silenced in (False, True):
                    result, arrays = trial(b, trial_seed, gain, silenced, 'candidate')
                    label = f'gain-{gain:.1f}_seed-{trial_seed}_' + ('silenced' if silenced else 'intact')
                    save(label, result, arrays)
                    validate(b, result, arrays)
                    assert result['initial_state'] == base['initial_state']
                    if trial_seed in seed_candidates:
                        assert np.array_equal(arrays['candidates'], seed_candidates[trial_seed])
                    else:
                        seed_candidates[trial_seed] = arrays['candidates'].copy()
                    pair.append(result)
                pairs.append(dict(gain=gain, seed=trial_seed, intact=pair[0]['mn9_count'],
                    silenced=pair[1]['mn9_count'], difference=pair[1]['mn9_count']-pair[0]['mn9_count'],
                    ratio=pair[1]['mn9_count']/pair[0]['mn9_count'] if pair[0]['mn9_count'] else None))
                (out / 'pairs.json').write_text(json.dumps(pairs, indent=2))
        for rel, expected_hash in protocol['sha256'].items():
            assert sha(ROOT / rel) == expected_hash, rel
        (out / 'completion.json').write_text(json.dumps(dict(complete=True, pairs=len(pairs),
            trials=len(pairs)*2, utc=dt.datetime.now(dt.timezone.utc).isoformat(),
            protocol_sha256=protocol_sha, biological_validation=False), indent=2))
        wd.write('completed')
    except Exception as exc:
        (out / 'failure.json').write_text(json.dumps(dict(type=type(exc).__name__, message=str(exc),
            utc=dt.datetime.now(dt.timezone.utc).isoformat(), complete=False), indent=2))
        raise
    finally:
        if lock_acquired and lock.exists() and lock.read_text() == str(os.getpid()):
            lock.unlink()


if __name__ == '__main__':
    main()

