"""Freeze once, before execution; never refresh an executed protocol."""
import datetime as dt
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if not __debug__:
    raise SystemExit('Refusing to freeze with assertions disabled')
target = HERE / 'PROTOCOL-v3.json'
assert not target.exists(), 'Refusing to replace a freeze'
prior = json.loads((ROOT / 'feasibility-2026-10-13/implementation/AMENDMENT.json').read_text())
paths = list(prior['sha256']) + [
    'feasibility-2026-10-13/implementation/AMENDMENT.json',
    'feasibility-2026-10-13/intact-seed0/counts.json',
    'paired-2026-10-13/paired_runner.py',
    'paired-2026-10-13/QUESTION.txt',
    'paired-2026-10-13/tiny-checks.json',
    'paired-2026-10-13/freeze.py',
    'paired-2026-10-13/verify_results.py',
]
hashes = {rel: hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() for rel in paths}
for rel, value in prior['sha256'].items():
    assert hashes[rel] == value, f'Historical source changed: {rel}'
protocol = dict(
    task='T-076', frozen_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
    before_any_paired_wholebrain_execution=True,
    question='Does Roundup outgoing-silencing sensitivity survive a +/-20% change in recurrent gain?',
    recurrent_gains=[1.0, .8, 1.2], seeds=[0, 1, 2, 3, 4],
    conditions=['intact', 'Roundup outgoing weights zero'], planned_trials=30,
    order='gain then seed then intact/silenced; full reset before every condition',
    stimulus_hz=100, external_amplitude_volts=.000275*250,
    external_amplitude_changed_with_recurrent_gain=False,
    duration_seconds=1.0, dt_seconds=.0001,
    mn9_id=720575940660219265, silenced_id=720575940623211725,
    upstream_commit=prior['upstream_commit'], sha256=hashes,
    python=platform.python_version(),
    packages={name: importlib.metadata.version(name) for name in
              ('brian2','numpy','pandas','pyarrow','sympy','psutil')},
    amendment='v3 before any wholebrain paired run: completed Claude review dispositions F1-F5; reject optimized Python and non-UTC deadlines, bind fresh tiny receipt to runner hash, verify pending spike and acquire lock before watchdog inside failure handling. Operator coordinates one numerical process across fly and EEG; stale PID lock clearance documented. Scientific grid unchanged. v2 retained in history/pre-v3-review-amendment.',
    maximum_attempt_seconds=1800,
    admission_minimum_GiB=dict(ram_avail=4, commit_avail=5, disk_free=1.5),
    resource_minimum_GiB=dict(physical=2, commit=3, disk=1),
    estimation='All individual paired differences and ratios; mean and range. Ratios undefined at zero intact. No tuning, p-value selection, power or biological uncertainty claim.',
    limitations=['Five random-input seeds; seed0 baseline previously inspected.',
                 'Only one neuron ID, stimulus rate, gain interval, model and connectome.',
                 '100 Hz alone cannot reproduce the paper multi-frequency phenotype criterion.',
                 'No biological validation, novelty claim or personal implementation claim.'])
target.write_text(json.dumps(protocol, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'path': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
