"""Freeze source-bound v4 after reviewed integration, before whole-brain execution."""
import ast
import datetime as dt
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

p = json.loads((HERE / 'PROTOCOL-v3.json').read_text())
for rel, expected in p['sha256'].items():
    assert sha(ROOT / rel) == expected, rel
fixture_rel = 'paired-2026-10-13/candidate-input-prototype/fixture-attempt04-20261014T1529/verification.json'
fixture = json.loads((ROOT / fixture_rel).read_text())
assert fixture['status'] == 'passed_small_network_only'
assert len(fixture['comparisons']) == 48
for rel, expected in fixture['source_hashes'].items():
    assert sha(ROOT / rel) == expected, rel
smoke = HERE / 'candidate-input-prototype/integration-smoke-20261014T1554/receipt.json'
s = json.loads(smoke.read_text())
assert s['passed'] and s['source_sha256'] == sha(HERE / 'paired_runner_v4.py')
files = ['paired_runner_v4.py', 'verify_results_v4.py', 'AMENDMENT-v4.json',
         'freeze_v4.py', 'check_v4_integration.py', 'PROTOCOL-v3.json',
         'candidate-input-prototype/candidate_drive.py',
         'candidate-input-prototype/reference_drive.py',
         'candidate-input-prototype/test_candidate_drive.py',
         'candidate-input-prototype/fixture-attempt04-20261014T1529/verification.json',
         'candidate-input-prototype/integration-smoke-20261014T1554/receipt.json']
for rel in files:
    path = HERE / rel
    if path.suffix == '.py':
        ast.parse(path.read_text(), filename=str(path))
    p['sha256'][path.relative_to(ROOT).as_posix()] = sha(path)
p.update(revision='v4', frozen_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
         before_any_paired_wholebrain_execution=False, before_any_v4_wholebrain_execution=True,
         fixture_receipt=fixture_rel, amendment='See AMENDMENT-v4.json; post-v3-failure candidate coupling. Scientific grid unchanged.',
         input_contract=dict(generator='PCG64', orientation='time-by-ordered-input',
                             candidate_probability=.01, acceptance='original not_refractory',
                             equality='candidates across conditions; applied events reconstructed with each mask'))
with (HERE / 'PROTOCOL-v4.json').open('x', encoding='utf-8') as f:
    json.dump(p, f, indent=2)
print(json.dumps(dict(protocol_sha256=sha(HERE / 'PROTOCOL-v4.json'), sources=len(p['sha256']), frozen_utc=p['frozen_utc'])))
