"""Read saved arrays independently; reject incomplete grids and source drift."""
import csv
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / 'results'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()


def array_sha(array):
    a = np.ascontiguousarray(array)
    return hashlib.sha256(str(a.dtype).encode()+str(a.shape).encode()+a.tobytes()).hexdigest()


def main():
    if not __debug__:
        raise SystemExit('Refusing to verify with assertions disabled')
    global OUT
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, default=OUT)
    args = ap.parse_args()
    OUT = args.out.resolve()
    protocol = json.loads((HERE/'PROTOCOL.json').read_text())
    complete = json.loads((OUT/'completion.json').read_text())
    assert complete['complete'] and complete['trials'] == 30 and complete['pairs'] == 15
    checks = []
    for rel, expected in protocol['sha256'].items():
        assert sha(ROOT/rel) == expected, rel
        checks.append('source:'+rel)
    gate = json.loads((OUT/'gate.json').read_text())
    assert all(gate.values())
    import pandas as pd
    ids = pd.read_csv(ROOT/'upstream/shiu_91bdd1e/2023_03_23_completeness_630_final.csv', index_col=0).index.to_numpy(dtype=np.int64)
    endpoint = np.flatnonzero(ids == protocol['mn9_id'])
    assert len(endpoint) == 1
    endpoint = int(endpoint[0])
    initial = json.loads((OUT/'gate-intact.json').read_text())['initial_state']
    inputs = {}
    rows = []
    file_hashes = {}
    for gain in protocol['recurrent_gains']:
        for seed in protocol['seeds']:
            pair = []
            for condition in ('intact','silenced'):
                label = f'gain-{gain:.1f}_seed-{seed}_{condition}'
                record = json.loads((OUT/(label+'.json')).read_text())
                with np.load(OUT/(label+'.npz'), allow_pickle=False) as data:
                    counts = data['counts']
                    events = data['input_events']
                    assert counts.shape == (127400,) and events.shape == (21,10000)
                    assert np.issubdtype(counts.dtype,np.integer) and np.all(counts >= 0)
                    assert np.isin(events,[0,1]).all()
                    assert int(counts[endpoint]) == record['mn9_count'] == len(record['mn9_times_seconds'])
                    assert int(counts.sum()) == record['total_spikes']
                    assert array_sha(counts) == record['all_counts_sha256']
                    assert array_sha(events) == record['input_sha256']
                    assert int(events.sum()) == record['input_event_count']
                    if seed in inputs:
                        assert np.array_equal(inputs[seed],events), label
                    else:
                        inputs[seed] = events.copy()
                assert record['seed'] == seed and record['recurrent_gain'] == gain
                assert record['silenced'] == (condition == 'silenced')
                assert record['duration_seconds'] == 1 and record['dt_seconds'] == .0001
                assert record['initial_state'] == initial and record['weights_checked'] == 14687178
                assert record['protocol_sha256'] == sha(HERE/'PROTOCOL.json')
                times = np.array(record['mn9_times_seconds'])
                assert np.all(times >= 0) and np.all(times < 1) and np.all(np.diff(times) > 0)
                pair.append(record['mn9_count'])
                checks.append('trial:'+label)
                for suffix in ('.json','.npz'):
                    file_hashes[label+suffix] = sha(OUT/(label+suffix))
            rows.append(dict(gain=gain, seed=seed, intact=pair[0], silenced=pair[1],
                             difference=pair[1]-pair[0], ratio=pair[1]/pair[0] if pair[0] else None))
    saved = json.loads((OUT/'pairs.json').read_text())
    assert len(saved) == len(rows)
    for a,b in zip(rows,saved):
        assert all(a[key] == b[key] for key in a)
    summary=[]
    for gain in protocol['recurrent_gains']:
        group=[r for r in rows if r['gain']==gain]
        ratios=[r['ratio'] for r in group if r['ratio'] is not None]
        summary.append(dict(recurrent_gain=gain, n_seeds=len(group),
            intact_mean_hz=float(np.mean([r['intact'] for r in group])),
            silenced_mean_hz=float(np.mean([r['silenced'] for r in group])),
            paired_mean_difference_hz=float(np.mean([r['difference'] for r in group])),
            ratio_of_means=float(np.mean([r['silenced'] for r in group])/np.mean([r['intact'] for r in group])) if any(r['intact'] for r in group) else None,
            individual_ratio_range=[float(min(ratios)),float(max(ratios))] if ratios else None,
            seeds_with_reduced_output=sum(r['difference']<0 for r in group)))
    with (HERE/'paired-results.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    receipt=dict(passed=True, checks=len(checks), checked=checks,
                 every_seed_input_identical_across_all_six_conditions=True,
                 distinct_input_seeds=len({array_sha(x) for x in inputs.values()}),
                 summary=summary, result_files_sha256=file_hashes,
                 protocol_sha256=sha(HERE/'PROTOCOL.json'),
                 verifier_sha256=sha(__file__), biological_validation=False)
    assert receipt['distinct_input_seeds']==5
    (HERE/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'passed':True,'checks':len(checks),'summary':summary},indent=2))


if __name__ == '__main__':
    main()
