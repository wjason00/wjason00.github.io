"""Bounded integration smoke test, separate from the unchanged scientific grid."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'feasibility-2026-10-13/implementation'))
from runner import Watchdog, sha

ap = argparse.ArgumentParser()
ap.add_argument('--out', type=Path, required=True)
args = ap.parse_args()
args.out.mkdir(exist_ok=False)
wd = Watchdog(str(args.out), time.time() + 300)
reason = wd.sample()
for k, minimum in dict(ram_avail=4, commit_avail=5, disk_free=1.5).items():
    if wd.mins[k] < minimum * 2**30:
        reason = reason or f'admission {k}'
rec = dict(admitted=reason is None, passed=False, initial_resources=wd.mins.copy(),
           utc=dt.datetime.now(dt.timezone.utc).isoformat(),
           deadline_utc=dt.datetime.fromtimestamp(wd.deadline, dt.timezone.utc).isoformat(),
           source_sha256=sha(HERE / 'paired_runner_v4.py'), numerical_scope='four-neuron mode-switch smoke only')
(args.out / 'receipt.json').write_text(json.dumps(rec, indent=2))
if reason:
    raise SystemExit(reason)
lock = HERE.parent / 'feasibility-2026-10-13/numerical.lock'
acquired = False
try:
    fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    acquired = True
    with os.fdopen(fd, 'w') as f:
        f.write(str(os.getpid()))
    wd.start()
    import numpy as np
    import paired_runner_v4 as v4
    b = v4.build(tiny=True)
    records = []
    for n, mode in enumerate(('historical', 'candidate', 'reference', 'candidate', 'historical')):
        result, arrays = v4.trial(b, 0, 1., False, mode, .05)
        np.savez_compressed(args.out / f'{n}-{mode}.npz', **arrays)
        (args.out / f'{n}-{mode}.json').write_text(json.dumps(result, indent=2))
        v4.validate(b, result, arrays)
        records.append((result, arrays))
    for i, j in ((0, 4), (1, 2), (1, 3)):
        assert records[i][0]['initial_state'] == records[j][0]['initial_state']
        for key in records[j][1]:
            assert np.array_equal(records[i][1][key], records[j][1][key]), (i, j, key)
    rec['passed'] = True
    rec['comparisons'] = ['historical return', 'candidate versus reference', 'candidate repeat']
except Exception as exc:
    rec['failure'] = dict(type=type(exc).__name__, message=str(exc))
    raise
finally:
    rec['minimum_resources'] = wd.mins
    rec['peak_rss'] = wd.peak_rss
    (args.out / 'receipt.json').write_text(json.dumps(rec, indent=2))
    if acquired and lock.exists() and lock.read_text() == str(os.getpid()):
        lock.unlink()
print(json.dumps(rec))
