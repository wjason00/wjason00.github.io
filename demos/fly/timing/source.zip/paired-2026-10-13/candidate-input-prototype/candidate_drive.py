"""Unvalidated input prototype. Not connected to the frozen whole-brain runner.

Candidate Bernoulli events are exogenous; refractory acceptance is endogenous.
This changes fixed-seed coupling and must not inherit v3 baseline identities.
"""
import numpy as np


def make_candidates(seed, ticks, input_count, *, rate_hz=100., dt_seconds=.0001):
    """Time-major schedule with a private PCG64 generator, independent of Brian RNG."""
    if ticks <= 0 or input_count <= 0 or not 0 <= rate_hz * dt_seconds <= 1:
        raise ValueError('Invalid Bernoulli schedule dimensions or probability')
    rng = np.random.Generator(np.random.PCG64(seed))
    values = rng.binomial(1, rate_hz * dt_seconds, size=(ticks, input_count)).astype(np.uint8)
    values.flags.writeable = False
    return values


class CandidateDrive:
    """Explicit original refractory mask at the original input scheduling slot.

    Install operation() before storing the network's initial state. After each
    restore, call arm() at time zero. Python-side records are deliberately reset
    explicitly: Brian's network store does not serialize these Python objects.
    Keep independent before/after voltage monitors for the actual applied check.
    """
    def __init__(self, neurons, indices, amplitude_volts, dt_seconds=.0001):
        self.neurons = neurons
        self.indices = np.asarray(indices, dtype=np.int64).copy()
        if self.indices.ndim != 1 or len(self.indices) != len(np.unique(self.indices)):
            raise ValueError('Inputs must be distinct neuron indices')
        if not len(self.indices) or np.any(self.indices < 0) or np.any(self.indices >= len(neurons)):
            raise ValueError('Input index outside neuron group')
        if not np.isfinite(amplitude_volts) or amplitude_volts <= 0:
            raise ValueError('Input amplitude must be finite and positive')
        if float(neurons.clock.dt) != dt_seconds:
            raise ValueError('Drive clock must match the declared neuron clock')
        self.amplitude = float(amplitude_volts)
        self.dt_seconds = dt_seconds
        self.candidates = None

    def arm(self, candidates):
        clock_values = self.neurons.clock.variables
        if (clock_values['timestep'].get_value().item() != 0
                or clock_values['t'].get_value().item() != 0):
            raise ValueError('Restore the network to time zero before arming input')
        data = np.asarray(candidates)
        if data.dtype != np.uint8 or data.ndim != 2 or data.shape[1] != len(self.indices):
            raise ValueError('Expected uint8 time-by-input candidate matrix')
        if not len(data) or not np.isin(data, [0, 1]).all():
            raise ValueError('Candidate entries must be Bernoulli events')
        self.candidates = data.copy()
        self.candidates.flags.writeable = False
        self.eligible = np.zeros(data.shape, dtype=bool)
        self.applied = np.zeros(data.shape, dtype=np.uint8)
        self.seen = np.zeros(len(data), dtype=bool)

    def step(self):
        if self.candidates is None:
            raise RuntimeError('Input has not been armed')
        tick = int(self.neurons.clock.variables['timestep'].get_value().item())
        if not 0 <= tick < len(self.candidates):
            raise RuntimeError('Unexpected input clock time or schedule exhaustion')
        if self.seen[tick] or (tick and not self.seen[tick-1]):
            raise RuntimeError('Repeated or skipped input tick; reset records after restore')
        mask = self.neurons.variables['not_refractory'].get_value()[self.indices].copy()
        events = self.candidates[tick] * mask.astype(np.uint8)
        # Direct values are intentional: the explicit mask implements the same
        # conditional write as the source PoissonInput. Never force blocked input.
        voltage = self.neurons.variables['v'].get_value()
        # Do not even add zero at blocked indices: their values stay untouched.
        voltage[self.indices[mask]] += self.amplitude * self.candidates[tick, mask]
        self.eligible[tick] = mask
        self.applied[tick] = events
        self.seen[tick] = True

    def operation(self):
        from brian2 import NetworkOperation
        return NetworkOperation(self.step, clock=self.neurons.clock, when='synapses', order=0,
                                name='paired_candidate_input')

    def check_complete(self, independently_observed_events):
        if not self.seen.all():
            raise AssertionError('Not all candidate ticks executed')
        if not np.array_equal(self.applied, self.candidates * self.eligible):
            raise AssertionError('Candidate acceptance reconstruction failed')
        if not np.array_equal(independently_observed_events, self.applied):
            raise AssertionError('Recorded voltage increments differ from applied input')
