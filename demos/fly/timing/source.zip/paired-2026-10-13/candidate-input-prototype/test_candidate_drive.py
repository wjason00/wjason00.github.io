"""Guarded, small-network comparison only; never loads whole-brain data."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
sys.path.insert(0, str(ROOT / 'feasibility-2026-10-13/implementation'))
sys.path.insert(0, str(ROOT / 'upstream/shiu_91bdd1e'))
from runner import Watchdog, sha


def digest(array):
    return hashlib.sha256(str(array.dtype).encode() + str(array.shape).encode() + array.tobytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Assertions must be enabled')
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--deadline-utc', required=True)
    args = parser.parse_args()
    deadline = dt.datetime.fromisoformat(args.deadline_utc)
    if deadline.utcoffset() != dt.timedelta(0) or not time.time() < deadline.timestamp() <= time.time() + 600:
        raise ValueError('Deadline must be explicit UTC and within ten minutes')
    args.out.mkdir(parents=True, exist_ok=False)
    watchdog = Watchdog(str(args.out), deadline.timestamp())
    reason = watchdog.sample()
    admission = {'ram_avail': 4, 'commit_avail': 5, 'disk_free': 1.5}
    for key, minimum in admission.items():
        if watchdog.mins[key] < minimum * 2**30:
            reason = reason or f'Admission failed: {key}'
    record = {'status': 'incomplete', 'scope': 'six synthetic neurons, two stimulated inputs; no whole-brain run',
              'reviewer': 'Codex; not Claude', 'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'deadline_utc': args.deadline_utc, 'admission_minimum_gib': admission,
              'initial_resources_bytes': {key: int(value) if value != float('inf') else None
                                          for key, value in watchdog.mins.items()},
              'runtime_minimum_gib': {'ram_avail': 2, 'commit_avail': 3, 'disk_free': 1},
              'checks': [], 'comparisons': [], 'phase': 'admission'}
    source_paths = [Path(__file__), HERE / 'reference_drive.py', HERE / 'candidate_drive.py',
                    ROOT / 'upstream/shiu_91bdd1e/model.py',
                    HERE.parent / 'PROTOCOL-v3.json',
                    ROOT / 'feasibility-2026-10-13/implementation/runner.py']
    record['source_hashes'] = {str(p.relative_to(ROOT)): sha(p) for p in source_paths}

    def save():
        (args.out / 'verification.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n', encoding='utf-8')

    save()
    if reason:
        record.update(status='refused_admission', error=reason)
        save()
        return 2
    watchdog.start()
    started = time.monotonic()
    try:
        import numpy as np
        import brian2 as br
        import model as upstream
        from candidate_drive import CandidateDrive, make_candidates
        from reference_drive import ReferenceDrive
        record['versions'] = {'numpy': np.__version__, 'brian2': br.__version__, 'python': sys.version.split()[0]}
        br.prefs.codegen.target = 'numpy'
        frozen = json.loads((HERE.parent / 'PROTOCOL-v3.json').read_text(encoding='utf-8'))
        rate_hz, dt_seconds = float(frozen['stimulus_hz']), float(frozen['dt_seconds'])
        assert rate_hz == 100. and dt_seconds == .0001
        assert frozen['seeds'] == [0, 1, 2, 3, 4]
        assert sorted(frozen['recurrent_gains']) == [.8, 1., 1.2] and frozen['planned_trials'] == 30
        p = dict(upstream.default_params)
        p['r_poi'] = rate_hz * br.Hz
        indices = np.array([0, 1], dtype=np.int64)
        pre = np.array([0, 1, 2, 2, 3, 4, 5, 1])
        post = np.array([2, 3, 0, 1, 1, 5, 2, 4])
        weights = np.array([400, 320, 400, 100, 180, 250, -20, 130])
        amplitude = p['w_syn'] * p['f_poi']
        assert float(amplitude) == frozen['external_amplitude_volts']
        ticks = 1000
        record['candidate_contract'] = {
            'rate_hz': rate_hz, 'dt_seconds': dt_seconds, 'bernoulli_probability': rate_hz * dt_seconds,
            'generator': 'numpy.random.Generator(numpy.random.PCG64(seed))', 'seeds': frozen['seeds'],
            'orientation': 'time-by-ordered-input', 'ordered_input_indices': indices.tolist(),
            'neuron_identity': 'synthetic fixture indices only; no FlyWire IDs',
            'standard_fixture_ticks': ticks, 'standard_fixture_duration_seconds': ticks * dt_seconds,
            'external_amplitude_volts': float(amplitude), 'scientific_grid_changed': False}

        def build(reference):
            clock = br.Clock(dt=dt_seconds * br.second)
            assert float(clock.dt) == dt_seconds
            neu = br.NeuronGroup(6, p['eqs'], method='linear', threshold=p['eq_th'], reset=p['eq_rst'],
                                 refractory='rfc', namespace=dict(p), clock=clock)
            neu.v = p['v_0']; neu.g = 0; neu.rfc = p['t_rfc']; neu.rfc[indices] = 0 * br.ms
            syn = br.Synapses(neu, neu, 'w : volt', on_pre='g += w', delay=p['t_dly'], clock=clock)
            syn.connect(i=pre, j=post); syn.w = weights * p['w_syn']
            assert syn.clock is clock and syn.pre.clock is clock and neu.clock is clock
            spikes = br.SpikeMonitor(neu)
            before = br.StateMonitor(neu, ['v', 'not_refractory'], record=indices, when='before_synapses')
            after = br.StateMonitor(neu, 'v', record=indices, when='after_synapses')
            trace = br.StateMonitor(neu, ['v', 'g', 'not_refractory', 'lastspike'], record=True, when='end')
            assert before.when == 'before_synapses' and after.when == 'after_synapses'
            assert before.clock is clock and after.clock is clock
            drive = ReferenceDrive(neu, indices, amplitude, clock.dt) if reference else CandidateDrive(
                neu, indices, float(amplitude), dt_seconds=dt_seconds)
            ops = drive.runners if reference else [drive.operation()]
            # Inspect the installed contract; this probe is never in the network.
            slot_probe = br.PoissonInput(neu[0:1], 'v', N=1, rate=p['r_poi'], weight=amplitude)
            slot_probe.active = False
            assert slot_probe.when == 'synapses' and slot_probe.order == 0 and slot_probe.clock is clock
            assert all(op.when == slot_probe.when and op.order == slot_probe.order and op.clock is clock for op in ops)
            net = br.Network(neu, syn, spikes, before, after, trace, *ops)
            net.store('initial')
            return dict(net=net, neu=neu, syn=syn, spikes=spikes, before=before, after=after,
                        trace=trace, drive=drive, reference=reference, slot_probe=slot_probe,
                        baseline=np.asarray(syn.w_[:]).copy())

        production, reference = build(False), build(True)
        record['checks'].append('installed unrun PoissonInput slot/clock, synaptic pathway clock and monitor slots agree')
        for invalid, duration in ((np.zeros((0, 2), np.uint8), 0.),
                                  (np.zeros((1, 1), np.uint8), dt_seconds),
                                  (np.zeros((1, 2), float), dt_seconds),
                                  (np.array([[2, 0]], np.uint8), dt_seconds),
                                  (np.zeros((1, 2), np.uint8), 2 * dt_seconds)):
            try:
                reference['drive'].arm(invalid, duration_seconds=duration)
            except ValueError:
                pass
            else:
                raise AssertionError('Reference accepted invalid candidates or duration')
        record['checks'].append('reference independently rejects empty/wrong shape/wrong dtype/nonbinary/duration-mismatched schedules')

        def run(b, candidates, gain=1., silenced=False, forced=None, observe=True):
            b['net'].restore('initial', restore_random_state=True)
            assert float(b['net'].t) == 0 and len(b['spikes'].t) == 0
            assert np.array_equal(np.asarray(b['syn'].w_[:]), b['baseline']), 'Stored baseline weights did not restore'
            for key in ('before', 'after', 'trace'):
                b[key].active = observe
            expected = b['baseline'] * gain
            if silenced:
                expected[pre == 2] = 0
            b['syn'].w_[:] = expected
            assert np.array_equal(np.asarray(b['syn'].w_[:]), expected)
            assert np.array_equal(np.asarray(b['syn'].i[:]), pre)
            assert np.array_equal(np.asarray(b['syn'].j[:]), post)
            duration_seconds = len(candidates) * dt_seconds
            if b['reference']:
                b['drive'].arm(candidates, duration_seconds=duration_seconds)
            else:
                b['drive'].arm(candidates)
            if forced is not None:
                b['neu'].v[forced] = -40 * br.mV
            b['net'].run(duration_seconds * br.second)
            if b['reference']:
                b['drive'].check_complete()
            result = {'counts': np.asarray(b['spikes'].count).copy(),
                      'spike_indices': np.asarray(b['spikes'].i).copy(), 'spike_times': np.asarray(b['spikes'].t).copy(),
                      'final_v': b['neu'].variables['v'].get_value().copy(),
                      'final_g': b['neu'].variables['g'].get_value().copy()}
            if observe:
                before_v = np.asarray(b['before'].v).T.copy()
                after_v = np.asarray(b['after'].v).T.copy()
                eligible = np.asarray(b['before'].not_refractory).T.copy()
                expected_v = before_v.copy()
                expected_v[eligible] += float(amplitude) * candidates[eligible]
                assert np.array_equal(after_v, expected_v), 'Independent voltage increment check failed'
                observed = np.rint((after_v - before_v) / float(amplitude)).astype(np.uint8)
                assert np.array_equal(observed, candidates * eligible)
                if not b['reference']:
                    b['drive'].check_complete(observed)
                    assert np.array_equal(eligible, b['drive'].eligible)
                result.update(eligible=eligible, applied=observed, before_v=before_v, after_v=after_v)
                for key in ('v', 'g', 'not_refractory', 'lastspike'):
                    result[key] = np.asarray(getattr(b['trace'], key)).copy()
            return result

        def same(a, b):
            assert set(a) == set(b)
            for key in a:
                assert np.array_equal(a[key], b[key]), f'Production/reference mismatch: {key}'

        # Force a spike on tick zero while that tick's candidate is present.
        record['phase'] = 'forced spike and next-tick acceptance'
        forced_candidates = np.ones((3, 2), dtype=np.uint8)
        forced_p = run(production, forced_candidates, forced=0)
        forced_r = run(reference, forced_candidates, forced=0)
        same(forced_p, forced_r)
        assert not forced_p['eligible'][0, 0] and forced_p['applied'][0, 0] == 0
        assert forced_p['eligible'][1, 0] and forced_p['applied'][1, 0] == 1
        try:
            reference['drive'].arm(forced_candidates, duration_seconds=len(forced_candidates) * dt_seconds)
        except ValueError:
            pass
        else:
            raise AssertionError('Reference accepted re-arm without restoring time zero')
        record['checks'].append('forced spike tick blocked at rfc=0; next tick accepted; independent reference exact')
        generated = reference['drive'].generated_code()
        assert all('not_refractory' in code and '[not_refractory]' in code for code in generated.values())
        (args.out / 'generated-reference-code.json').write_text(json.dumps(generated, indent=2), encoding='utf-8')

        schedules = {'zeros': np.zeros((ticks, 2), np.uint8), 'ones': np.ones((ticks, 2), np.uint8)}
        asymmetric = np.zeros((ticks, 2), np.uint8)
        asymmetric[::19, 0] = 1; asymmetric[7::37, 1] = 1
        schedules['asymmetric'] = asymmetric
        for seed in frozen['seeds']:
            schedules[f'seed-{seed}'] = make_candidates(seed, ticks, len(indices), rate_hz=rate_hz, dt_seconds=dt_seconds)
        manifests = {}
        for name, candidates in schedules.items():
            metadata = {'candidate_sha256': digest(candidates), 'ordered_input_indices': indices.tolist(),
                        'seed': int(name[5:]) if name.startswith('seed-') else None,
                        'generator': record['candidate_contract']['generator'] if name.startswith('seed-') else 'deterministic fixture',
                        'rate_hz': rate_hz if name.startswith('seed-') else None, 'dt_seconds': dt_seconds,
                        'ticks': len(candidates), 'orientation': 'time-by-ordered-input'}
            metadata['identity_sha256'] = hashlib.sha256(json.dumps(metadata, sort_keys=True).encode()).hexdigest()
            manifests[name] = metadata
        record['candidate_manifests'] = manifests
        differences = {'between_inputs': 0, 'between_conditions': 0}
        for name, candidates in schedules.items():
            for gain in (.8, 1., 1.2):
                baseline = None
                for silenced in (False, True):
                    record['phase'] = f'{name}, gain {gain}, silenced {silenced}'
                    a = run(production, candidates, gain, silenced)
                    b = run(reference, candidates, gain, silenced)
                    assert digest(candidates) == manifests[name]['candidate_sha256']
                    assert production['drive'].indices.tolist() == reference['drive'].indices == manifests[name]['ordered_input_indices']
                    same(a, b)
                    differences['between_inputs'] += int(np.count_nonzero(a['eligible'][:, 0] != a['eligible'][:, 1]))
                    if baseline is None:
                        baseline = a
                    else:
                        differences['between_conditions'] += int(np.count_nonzero(a['eligible'] != baseline['eligible']))
                    label = f'{name}_gain-{gain:.1f}_silenced-{silenced}'
                    np.savez_compressed(args.out / (label + '.npz'), candidates=candidates, **a)
                    record['comparisons'].append({'schedule': name, 'gain': gain, 'silenced': silenced,
                        'candidate_sha256': digest(candidates), 'candidate_identity_sha256': manifests[name]['identity_sha256'],
                        'counts': a['counts'].tolist(),
                        'applied_events': int(a['applied'].sum()), 'arrays_sha256': {key: digest(value) for key, value in a.items()},
                        'production_reference_exact': True, 'observed_candidate_mask_exact': True})
                save()
            watchdog.write(name)
        assert all(value > 0 for value in differences.values()), 'Fixture failed to exercise distinct eligibility'
        record['eligibility_differences'] = differences
        record['checks'].append('48 exact production/reference comparisons: zero/all-one/asymmetric/five seeds × three gains × two conditions')

        record['phase'] = 'restore after pending delay and other seed'
        candidates = schedules['seed-0']
        baseline = run(production, candidates)
        run(production, schedules['seed-4'], .8, True)
        same(baseline, run(production, candidates))
        production['net'].restore('initial', restore_random_state=True)
        production['drive'].arm(np.zeros((1, 2), np.uint8))
        production['neu'].v[2] = -40 * br.mV
        production['net'].run(dt_seconds * br.second)
        assert int(production['spikes'].count[2]) == 1
        assert float(production['net'].t) < float(p['t_dly'])
        same(baseline, run(production, candidates))
        record['checks'].append('pending delayed spike observed then restore/arm clears effects; other seed/silencing restores exactly')
        unobserved = run(production, candidates, observe=False)
        for key, value in unobserved.items():
            assert np.array_equal(value, baseline[key]), f'Observation changed {key}'
        record['checks'].append('voltage/state observations disabled: all spike identities/times/counts and final v/g unchanged')
        # The private candidate generator must not consume NumPy's global stream.
        np.random.seed(123)
        rng_state = np.random.get_state()
        assert np.array_equal(make_candidates(2, ticks, len(indices), rate_hz=rate_hz, dt_seconds=dt_seconds), schedules['seed-2'])
        next_value = np.random.random()
        np.random.set_state(rng_state)
        assert next_value == np.random.random()
        record['checks'].append('private PCG64 schedule reproducible; global NumPy stream unchanged')
        assert record['source_hashes'] == {str(path.relative_to(ROOT)): sha(path) for path in source_paths}
        record.update(status='passed_small_network_only', full_simulation_qualified=False,
                      whole_brain_run=False, scientific_grid_changed=False,
                      reference_generated_code_sha256=sha(args.out / 'generated-reference-code.json'),
                      output_hashes={path.name: sha(path) for path in sorted(args.out.glob('*.npz'))})
        watchdog.write('completed_small_network_tests')
    except Exception as error:
        record.update(status='failed', error=f'{type(error).__name__}: {error}', traceback=traceback.format_exc())
        watchdog.write('failed_small_network_tests')
        raise
    finally:
        record['elapsed_seconds'] = time.monotonic() - started
        # Preventive JSON normalization; successful admission already established
        # finite native minima, so no observed successful-run defect is claimed.
        record['min_resources'] = {key: int(value) if value != float('inf') else None
                                   for key, value in watchdog.mins.items()}
        record['peak_rss'] = int(watchdog.peak_rss)
        save()
        print(json.dumps({key: record.get(key) for key in ('status', 'phase', 'error', 'elapsed_seconds')}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
