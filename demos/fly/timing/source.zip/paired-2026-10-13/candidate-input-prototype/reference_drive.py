"""Independent Brian conditional-write reference; no production application helper."""
import numpy as np
from brian2 import TimedArray


class ReferenceDrive:
    def __init__(self, neurons, indices, amplitude, dt):
        self.neurons, self.indices, self.dt = neurons, list(indices), dt
        neurons.namespace['reference_amplitude'] = amplitude
        self.runners = []
        for column, index in enumerate(self.indices):
            name = f'reference_candidates_{column}'
            neurons.namespace[name] = TimedArray([0.], dt=dt)
            subgroup = neurons[index:index + 1]
            self.runners.append(subgroup.run_regularly(
                f'v += {name}(t) * reference_amplitude', clock=neurons.clock,
                when='synapses', order=0, name=f'reference_input_{column}'))

    def arm(self, candidates, *, duration_seconds):
        clock_values = self.neurons.clock.variables
        if (clock_values['timestep'].get_value().item() != 0
                or clock_values['t'].get_value().item() != 0):
            raise ValueError('Reference must be restored to time zero before arming')
        data = np.asarray(candidates)
        if data.dtype != np.uint8 or data.ndim != 2 or data.shape[1] != len(self.indices):
            raise ValueError('Reference requires uint8 time-by-input candidates')
        if len(data) == 0 or not np.isin(data, [0, 1]).all():
            raise ValueError('Reference candidates must be nonempty binary events')
        if (not np.isfinite(duration_seconds)
                or duration_seconds != len(data) * float(self.dt)):
            raise ValueError('Reference duration must exactly span the candidate schedule')
        self.expected_ticks = len(data)
        for column in range(len(self.indices)):
            self.neurons.namespace[f'reference_candidates_{column}'] = TimedArray(
                data[:, column].astype(float), dt=self.dt)

    def check_complete(self):
        ticks = self.neurons.clock.variables['timestep'].get_value().item()
        if ticks != self.expected_ticks:
            raise AssertionError('Reference ran fewer or more ticks than its candidate schedule')

    def generated_code(self):
        return {runner.name: str(runner.codeobj.code.run) for runner in self.runners}
