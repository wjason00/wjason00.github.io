# Fixed-schedule fly timing pilot: source for inspection

This archive preserves a whitelist of frozen source dependencies, protocols,
small historical qualification receipts, the timing fixture and ten input
schedules. Paths retain the original pilot-root layout. It contains no full
connectome, raw whole-network simulation arrays, virtual environment, private
application material or portfolio presentation. INVENTORY.json gives exact
member SHA-256 hashes. The frozen protocol also records the omitted data hashes.

This is source for inspection, not portable one-click execution. To inspect
the timing experiment, start with timing-2026-10-19/PROTOCOL.json,
timing_inputs.py, timing_runner.py and README.md. Historical protocols describe
older experiments; they are included to satisfy the frozen dependency manifest,
not as specifications or findings for this timing pilot.

For reproduction, acquire the two exact upstream v630 data files listed in
UPSTREAM-DATA.json, place them at their listed relative paths and verify their
SHA-256 hashes. Do not substitute v783. The upstream source is pinned to the
recorded commit. Required libraries and the Windows environment are documented
in ENVIRONMENT.json and requirements-recorded.txt. These versions differ from
the authors' older environment files, retained under upstream/. The native
watchdog uses Windows system-commit APIs; another platform needs a separately
qualified resource guard. No cross-platform or installation validation is claimed.

The frozen runner intentionally has dated task-start, runtime and absolute
deadline guards, including 2026-10-19T22:25:00Z. They prevent unmodified future
grid execution. Do not overwrite the archived protocol, fixture or schedules.
For a later reproduction, preserve this archive, use a new working copy and
new output directories, document and update execution timestamps/deadline
controls, rerun the small fixtures and refreeze the changed source. Retain the
scientific controls: neuron IDs, full v630 graph, three intervention conditions,
five schedule seeds, gain, amplitude, simulator timestep, original refractory
acceptance, period/repeats and middle half-open analysis window. Then qualify
the full-network candidate/reference gate before running the scientific grid.
Any scientific-control change defines a new experiment and must be documented.

The archive's historical verification JSON files are provenance, not proof that
a future modified environment will match. The package verification only checks
hashes, syntax and schedule/import invariants as recorded in the delivery receipt.
It does not rerun the full network. Full local raw arrays are omitted; the public
evidence exports accompanying this package provide selected spike times and
per-cell summaries. This package does not claim biological validation, measured
movement, causal inhibition, mediation, steady state or field novelty.

See ATTRIBUTION.md and the upstream MIT notice for source terms and credit.
