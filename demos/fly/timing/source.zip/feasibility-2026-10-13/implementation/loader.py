"""Lean streaming loader: Presynaptic_Index, Postsynaptic_Index, Excitatory x Connectivity -> int32."""
import numpy as np
import pyarrow.parquet as pq

COLS = ["Presynaptic_Index", "Postsynaptic_Index", "Excitatory x Connectivity"]
I32 = np.iinfo(np.int32)


def load_edges(path, n_neurons, batch_size=1_000_000):
    pf = pq.ParquetFile(path)
    n = pf.metadata.num_rows
    out = [np.empty(n, dtype=np.int32) for _ in COLS]
    pos = 0
    for b in pf.iter_batches(batch_size=batch_size, columns=COLS):
        m = b.num_rows
        for k, name in enumerate(COLS):
            col = b.column(name)
            if col.null_count:
                raise ValueError(f"nulls in {name}")
            a = col.to_numpy(zero_copy_only=False)
            if a.dtype.kind not in "iu":
                raise TypeError(f"non-integer {name}: {a.dtype}")
            if m and (a.min() < I32.min or a.max() > I32.max):
                raise OverflowError(f"int32 range exceeded in {name}")
            if k < 2 and m and (a.min() < 0 or a.max() >= n_neurons):
                raise IndexError(f"{name} out of [0,{n_neurons})")
            out[k][pos:pos + m] = a
        pos += m
    if pos != n:
        raise RuntimeError(f"row count {pos} != metadata {n}")
    return tuple(out)
