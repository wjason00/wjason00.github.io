import datetime as dt,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
import numpy as np,pandas as pd,pyarrow as pa,pyarrow.parquet as pq
from brian2 import *
from loader import load_edges,COLS
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];UP=ROOT/'upstream'/'shiu_91bdd1e'
sys.path.insert(0,str(UP));import model as up
prefs.codegen.target='numpy'
results=[]
with tempfile.TemporaryDirectory(dir=HERE) as d:
 d=Path(d);comp=d/'comp.csv';con=d/'con.parquet'
 pd.DataFrame({'x':[1,1,1]},index=[720575940000000001,720575940000000002,720575940000000003]).to_csv(comp)
 table=pa.table(dict(zip(COLS,[pa.array([0,1,2],type=pa.int64()),pa.array([1,2,0],type=pa.int64()),pa.array([400,400,-10],type=pa.int64())])))
 pq.write_table(table,con)
 for use_lean in [False,True]:
  start_scope();seed(0);defaultclock.dt=.1*ms;p=dict(up.default_params)
  if not use_lean:neu,syn,unused=up.create_model(comp,con,p)
  else:
   pre,post,w=load_edges(con,3,batch_size=2)
   neu=NeuronGroup(3,p['eqs'],method='linear',threshold=p['eq_th'],reset=p['eq_rst'],refractory='rfc',name='default_neurons',namespace=p)
   neu.v=p['v_0'];neu.g=0;neu.rfc=p['t_rfc']
   syn=Synapses(neu,neu,'w : volt',on_pre='g += w',delay=p['t_dly'],name='default_synapses')
   syn.connect(i=pre,j=post);syn.w=w*p['w_syn']
   assert np.array_equal(syn.i[:],pre) and np.array_equal(syn.j[:],post) and np.array_equal(syn.w_[:],np.asarray(w*p['w_syn']))
  neu.v[0]=-40*mV
  all_mon=SpikeMonitor(neu,record=True);counts=SpikeMonitor(neu,record=False);endpoint=SpikeMonitor(neu[1:2],record=True)
  net=Network(neu,syn,all_mon,counts,endpoint);net.run(30*ms)
  assert np.array_equal(counts.count[:],all_mon.count[:])
  assert np.array_equal(endpoint.t/second,np.asarray(all_mon.t/second)[np.asarray(all_mon.i)==1])
  results.append({'counts':all_mon.count[:].tolist(),'i':all_mon.i[:].tolist(),'times_seconds':np.asarray(all_mon.t/second).tolist(),'weights':syn.w_[:].tolist()})
 assert results[0]==results[1] and results[1]['counts'][1]>0
 stopdir=d/'watchdog';stopdir.mkdir()
 command="from runner import Watchdog;import time;w=Watchdog("+repr(str(stopdir))+",time.time()-1);w.start();time.sleep(3)"
 child=subprocess.run([sys.executable,'-c',command],cwd=HERE,capture_output=True,text=True,timeout=10)
 assert child.returncode==3 and json.loads((stopdir/'watchdog.json').read_text())['stop_reason']=='deadline reached'
receipt={'passed':True,'upstream_vs_lean_tiny_exact':True,'synapse_driven_neuron_spiked':True,'counts_only_matches_full':True,'mn9_style_subgroup_times_match_full':True,'watchdog_expired_deadline_child_exit3':True,'tiny_result':results[1],'checked_utc':dt.datetime.now(dt.timezone.utc).isoformat()}
(HERE/'post-review-checks.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
amend=json.loads((HERE/'AMENDMENT.json').read_text())
amend['review_revision']=2;amend['frozen_utc']=dt.datetime.now(dt.timezone.utc).isoformat()
amend['deviations'][1]='All-neuron counts-only monitor plus one-neuron MN9 subgroup spike-time monitor; tiny downstream-spiking fixture verified against full-spike monitor.'
amend['deviations']+=['Explicit numpy codegen, BLAS/OpenMP thread limit1; original upstream equations/reset kept.','Loaded arrays and Brian2 connected pre/post/weight arrays compared exactly in65536rowchunks before simulation; sourcevalues independently verified.','131072row loader batches; measured simulation time, endpointtimes, phases, resource telemetry and source-binding hash saved.']
for rel in list(amend['sha256']):amend['sha256'][rel]=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
amend['sha256']['feasibility-2026-10-13/implementation/review_checks.py']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(HERE/'AMENDMENT.json').write_text(json.dumps(amend,indent=2),encoding='utf-8')
print(json.dumps(receipt))
