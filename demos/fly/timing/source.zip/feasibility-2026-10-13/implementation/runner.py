"""Intact-only, seed 0, one-process runner (NOT EXECUTED here; root launches).
Usage: python runner.py --out DIR --deadline-utc 2026-10-13T09:30:00Z
"""
import argparse, ctypes, datetime as dt, hashlib, json, os, shutil, sys, threading, time
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'
import psutil

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
UP = os.path.join(ROOT, "upstream", "shiu_91bdd1e")
GIB = 1 << 30
LIMITS = {"ram_avail": 2 * GIB, "disk_free": 1 * GIB, "commit_avail": 3 * GIB}


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def commit_avail():
    class MS(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong)] + \
                   [(n, ctypes.c_ulonglong) for n in ("tp", "ap", "tpf", "apf", "tv", "av", "aev")]
    m = MS(); m.dwLength = ctypes.sizeof(MS)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
    return m.apf


class Watchdog(threading.Thread):
    def __init__(self, out, deadline, poll=0.5):
        super().__init__(daemon=True)
        self.out, self.deadline, self.poll = out, deadline, poll
        self.mins = {k: float("inf") for k in LIMITS}; self.peak_rss = 0; self.stop_reason = None
        self.proc = psutil.Process()

    def sample(self):
        s = {"ram_avail": psutil.virtual_memory().available, "disk_free": shutil.disk_usage(self.out).free,
             "commit_avail": commit_avail()}
        for k, v in s.items():
            self.mins[k] = min(self.mins[k], v)
            if v < LIMITS[k]:
                return f"{k} {v} < {LIMITS[k]}"
        self.peak_rss = max(self.peak_rss, self.proc.memory_info().rss)
        if time.time() >= self.deadline:
            return "deadline reached"
        return None

    def run(self):
        while True:
            r = self.sample()
            if r:
                self.stop_reason = r; self.write("watchdog_stop"); os._exit(3)  # own process only
            time.sleep(self.poll)

    def write(self, status):
        with open(os.path.join(self.out, "watchdog.json"), "w") as f:
            json.dump({"status": status, "stop_reason": self.stop_reason, "min_resources": self.mins,
                       "peak_rss": self.peak_rss, "utc": dt.datetime.utcnow().isoformat()}, f, indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True); ap.add_argument("--deadline-utc", required=True)
    a = ap.parse_args()
    if os.path.exists(a.out):
        sys.exit(f"refusing: output exists {a.out}")
    os.makedirs(a.out)
    deadline = dt.datetime.fromisoformat(a.deadline_utc.replace("Z", "+00:00")).timestamp()
    wd = Watchdog(a.out, deadline)
    r = wd.sample()
    if r:
        wd.stop_reason = r; wd.write("refused_preflight"); sys.exit(f"preflight: {r}")
    wd.start()  # active before any loading
    start = time.monotonic()
    def phase(name):
        rec = {'phase': name, 'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic()-start}
        print(json.dumps(rec), flush=True)
        with open(os.path.join(a.out,'phases.jsonl'),'a') as f: f.write(json.dumps(rec)+'\n')
        wd.write(name)
    phase('verify_sources')
    amend = json.load(open(os.path.join(HERE, "AMENDMENT.json")))
    for rel, h in amend["sha256"].items():
        if sha(os.path.join(ROOT, rel)) != h:
            sys.exit(f"hash mismatch: {rel}")
    import numpy as np, pandas as pd
    from brian2 import NeuronGroup, Synapses, PoissonInput, SpikeMonitor, Network, seed, defaultclock, prefs, ms, mV, Hz, second
    prefs.codegen.target = 'numpy'
    sys.path.insert(0, HERE); sys.path.insert(0, UP)
    from loader import load_edges
    import model as up  # upstream params/equations, unmodified
    p = dict(up.default_params); p["r_poi"] = 100 * Hz
    proto = json.load(open(os.path.join(ROOT, "PROTOCOL.json")))
    stim = proto["inputs"]["stimulated_neurons"]; mn9 = proto["endpoint"]["neuron"]
    assert len(stim) == len(set(stim)) == 21 and mn9 == 720575940660219265
    comp = pd.read_csv(os.path.join(UP, "2023_03_23_completeness_630_final.csv"), index_col=0)
    ids = comp.index.to_numpy(dtype=np.int64)  # order preserved; Brian index = row position
    assert len(ids) == len(np.unique(ids)) == 127400
    id2i = {int(x): i for i, x in enumerate(ids)}
    exc = [id2i[int(x)] for x in stim]; mn9_i = id2i[mn9]
    phase('load_edges')
    pre, post, wc = load_edges(os.path.join(UP, "2023_03_23_connectivity_630_final.parquet"), len(ids), batch_size=131072)
    assert len(pre) == len(post) == len(wc) == 14687178
    phase('construct_neurons')
    seed(0); defaultclock.dt = 0.1 * ms
    neu = NeuronGroup(len(ids), p["eqs"], method="linear", threshold=p["eq_th"], reset=p["eq_rst"],
                      refractory="rfc", name="default_neurons", namespace=p)
    neu.v = p["v_0"]; neu.g = 0; neu.rfc = p["t_rfc"]
    syn = Synapses(neu, neu, "w : volt", on_pre="g += w", delay=p["t_dly"], name="default_synapses")
    phase('connect_synapses')
    syn.connect(i=pre, j=post); syn.w = wc * p["w_syn"]
    assert len(syn) == 14687178
    phase('verify_connected_arrays')
    for lo in range(0,len(pre),65536):
        hi=min(lo+65536,len(pre))
        assert np.array_equal(syn.i[lo:hi],pre[lo:hi])
        assert np.array_equal(syn.j[lo:hi],post[lo:hi])
        assert np.array_equal(syn.w_[lo:hi],np.asarray(wc[lo:hi]*p['w_syn']))
    connected = {'all_rows_exact_pre_post_weight':True,'rows':len(pre),'chunk_size':65536}
    json.dump(connected,open(os.path.join(a.out,'connected-array-verification.json'),'w'),indent=1)
    del pre, post, wc
    pois = []
    for i in exc:
        pois.append(PoissonInput(target=neu[i], target_var="v", N=1, rate=p["r_poi"], weight=p["w_syn"] * p["f_poi"]))
        neu[i].rfc = 0 * ms
    mon = SpikeMonitor(neu, record=False)  # counts only (observational change)
    endpoint_mon = SpikeMonitor(neu[mn9_i:mn9_i+1], record=True)
    net = Network(neu, syn, mon, endpoint_mon, *pois)
    build_seconds = time.monotonic()-start
    phase('simulate_1_second')
    t0 = time.time(); net.run(p["t_run"]); t_run = time.time() - t0
    phase('verify_and_save_result')
    counts = np.asarray(mon.count)
    duration_seconds = float(net.t/second)
    mn9_times = np.asarray(endpoint_mon.t/second)
    assert duration_seconds == 1.0 and float(defaultclock.dt/second) == 0.0001
    assert len(mn9_times) == int(counts[mn9_i]) == int(endpoint_mon.count[0])
    res = {"seed": 0, "condition": "intact", "n_neurons": len(ids), "n_synapses": int(len(syn)),
           "mn9_id": mn9, "mn9_count": int(counts[mn9_i]), "total_spikes": int(counts.sum()),
           "nonzero": {str(int(ids[i])): int(counts[i]) for i in np.flatnonzero(counts)}, "run_seconds": t_run,
           "duration_seconds": duration_seconds, "dt_seconds":float(defaultclock.dt/second),
           "mn9_times_seconds": mn9_times.tolist(), "build_seconds":build_seconds,
           "amendment_sha256":sha(os.path.join(HERE,'AMENDMENT.json')), "codegen_target":prefs.codegen.target,
           "connected_arrays_verified":connected}
    json.dump(res, open(os.path.join(a.out, "counts.json"), "w"), indent=1)
    wd.write("completed")


if __name__ == "__main__":
    main()
